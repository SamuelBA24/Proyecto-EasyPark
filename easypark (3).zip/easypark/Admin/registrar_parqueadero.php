<?php
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.php"); 
    exit();
}
include '../conexion.php'; 

// 🚨 CORRECCIÓN FINAL: Forzar el ID de administrador a ser un entero puro.
$admin_id = (int)$_SESSION['usuario_id']; // <--- CAMBIO CLAVE AQUÍ
$mensaje = "";

// =========================================================
// 1. MANEJAR REGISTRO DE NUEVO PARQUEADERO CON IMAGEN
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'registrar_parking') {
    $nombre = $conn->real_escape_string($_POST['nombre_parqueadero']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    
    // Procesar la imagen subida
    $imagen_nombre = NULL;
    if (isset($_FILES['imagen_parqueadero']) && $_FILES['imagen_parqueadero']['error'] == 0) {
        $archivo = $_FILES['imagen_parqueadero'];
        $extension = strtolower(pathinfo($archivo['name'], PATHINFO_EXTENSION));
        $extensiones_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        
        if (in_array($extension, $extensiones_permitidas)) {
            // Crear carpeta si no existe
            $carpeta_destino = '../uploads/parqueaderos/';
            if (!file_exists($carpeta_destino)) {
                mkdir($carpeta_destino, 0777, true);
            }
            
            // Generar nombre único para la imagen
            $imagen_nombre = 'park_' . time() . '_' . uniqid() . '.' . $extension;
            $ruta_completa = $carpeta_destino . $imagen_nombre;
            
            // Mover archivo a la carpeta de destino
            if (!move_uploaded_file($archivo['tmp_name'], $ruta_completa)) {
                $imagen_nombre = NULL;
                $mensaje = "⚠️ Advertencia: El parqueadero se registrará sin imagen (error al subir archivo).";
            }
        } else {
            $mensaje = "⚠️ Advertencia: Formato de imagen no permitido. Use JPG, PNG, GIF o WEBP.";
        }
    }

    // Insertar con o sin imagen
    $sql_insert = "INSERT INTO parqueaderos (admin_id, nombre_parqueadero, direccion, imagen) 
                   VALUES ('$admin_id', '$nombre', '$direccion', " . ($imagen_nombre ? "'$imagen_nombre'" : "NULL") . ")";
    
    if ($conn->query($sql_insert) === TRUE) {
        $mensaje_exito = urlencode("✅ Parqueadero '$nombre' registrado con éxito.");
        header("Location: registrar_parqueadero.php?msg=" . $mensaje_exito);
        exit();
    } else {
        $mensaje = "❌ Error al registrar parqueadero: " . $conn->error;
    }
}

// =========================================================
// 2. MANEJAR DESACTIVACIÓN DE PARQUEADERO (BORRADO LÓGICO)
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'eliminar_parking') {
    $parqueadero_a_desactivar = $conn->real_escape_string($_POST['parqueadero_id']);
    
    // Verificación de seguridad: No se debe desactivar si tiene espacios OCUPADOS
    $sql_check_ocupados = "SELECT COUNT(e.id) AS ocupados FROM espacios e
                           WHERE e.parqueadero_id = '$parqueadero_a_desactivar' AND e.estado = 'ocupado' AND e.activo = TRUE";
    $res_ocupados = $conn->query($sql_check_ocupados)->fetch_assoc();

    if ((int)$res_ocupados['ocupados'] > 0) {
        $mensaje = "❌ Error: No se puede desactivar el parqueadero. Hay " . $res_ocupados['ocupados'] . " puesto(s) ocupado(s) actualmente. Deben desocuparse primero.";
    } else {
        // Desactivar el parqueadero (UPDATE activo = FALSE)
        $sql_update_parking = "UPDATE parqueaderos SET activo = FALSE WHERE id = '$parqueadero_a_desactivar' AND admin_id = '$admin_id'";
        
        // Desactivar todos los espacios asociados 
        $sql_update_espacios = "UPDATE espacios SET activo = FALSE WHERE parqueadero_id = '$parqueadero_a_desactivar'";

        if ($conn->query($sql_update_parking) === TRUE && $conn->query($sql_update_espacios) === TRUE) {
             // Redirigir después de POST/UPDATE
            $mensaje_exito = urlencode("✅ Parqueadero desactivado con éxito.");
            header("Location: registrar_parqueadero.php?msg=" . $mensaje_exito);
            exit();
        } else {
            $mensaje = "❌ Error al desactivar el parqueadero: " . $conn->error;
        }
    }
}

// Capturar mensajes de éxito después de la redirección
if (isset($_GET['msg'])) {
    $mensaje = urldecode($_GET['msg']);
}


// =========================================================
// 3. OBTENER LOS PARQUEADEROS ACTIVOS DEL ADMINISTRADOR (LISTADO)
// =========================================================
// Usamos el ID limpio en la consulta
$sql_parkings = "SELECT id, nombre_parqueadero, direccion, imagen FROM parqueaderos WHERE admin_id = '$admin_id' AND activo = TRUE ORDER BY id DESC";
$resultado_parkings = $conn->query($sql_parkings);

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Registrar/Gestionar Parqueaderos</title>
    <style>
        :root {
            --bg: #f6f8fa;
            --card: #fff;
            --accent: #1266d5;
            --muted: #6b7280;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
        }
        body { font-family: 'Inter', Arial, sans-serif; background: var(--bg); color: #1a2330; margin: 0; padding: 0; }
        .container { max-width: 820px; margin: 38px auto 0 auto; background: var(--card); padding: 32px 24px 24px 24px; border-radius: var(--radius); box-shadow: var(--shadow); }
        .header-admin { display: flex; flex-direction: column; align-items: center; margin-bottom: 18px; }
        .header-admin img { height: 80px; width: auto; margin-bottom: 8px; }
        .header-admin h1 { font-size: 2em; font-weight: 700; color: var(--accent); margin: 0; letter-spacing: 1px; text-align: center; }
        .menu-admin { text-align: center; margin-bottom: 18px; }
        .menu-admin a { margin: 0 10px; color: var(--accent); text-decoration: none; font-weight: 500; padding: 4px 10px; border-radius: 8px; transition: background 0.18s; }
        .menu-admin a:hover { background: #f0f8ff; text-decoration: underline; }
        .alerta { padding: 12px 0; margin-bottom: 20px; border-radius: 10px; font-weight: 500; text-align: center; font-size: 1em; }
        .exito { background-color: #eafbe7; color: #1e8f40; border: 1px solid #c3e6cb; }
        .error { background-color: #fff0f0; color: #dc3545; border: 1px solid #f5c6cb; }
        .card {
            background: #f6f8fa;
            border-radius: 16px;
            box-shadow: 0 2px 8px rgba(16,32,64,0.04);
            padding: 24px 18px;
            margin-bottom: 28px;
        }
        .form-registro { margin-top: 0; padding: 0; border: none; }
        .form-registro h2 { font-size: 1.2em; color: var(--accent); font-weight: 600; margin-bottom: 12px; text-align: center; }
        .form-registro label { display: block; margin-bottom: 6px; font-weight: 500; color: #1a2330; margin-top: 12px; }
        .form-registro input[type="text"], .form-registro input[type="file"] { width: 100%; padding: 12px 14px; margin-bottom: 16px; border: 1px solid #e2e8f0; border-radius: 12px; box-sizing: border-box; font-size: 1em; background: #f8fafc; color: #1a2330; transition: border-color 0.2s; }
        .form-registro input[type="text"]:focus, .form-registro input[type="file"]:focus { border-color: var(--accent); outline: none; }
        .form-registro input[type="file"] { padding: 10px 14px; cursor: pointer; }
        .form-registro button[type="submit"] { width: 100%; padding: 12px 0; background: linear-gradient(90deg,var(--accent),#0b5ed7); color: #f4f4f4; border: none; border-radius: 12px; font-weight: 600; font-size: 1em; letter-spacing: 0.5px; cursor: pointer; box-shadow: 0 2px 8px rgba(16,32,64,0.07); margin-top: 4px; margin-bottom: 5px; transition: background 0.2s, transform 0.15s; }
        .form-registro button[type="submit"]:hover { background: linear-gradient(90deg,#0b5ed7,var(--accent)); transform: translateY(-2px) scale(1.02); }
        
        .listado-parkings { margin-top: 0; padding: 0; border: none; }
        .listado-parkings h2 { font-size: 1.1em; color: var(--accent); font-weight: 600; margin-bottom: 10px; text-align: center; }
        
        /* GRID DE TARJETAS PARA PARQUEADEROS */
        .parkings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .parking-card-item {
            background: #ffffff;
            border-radius: 14px;
            box-shadow: 0 2px 12px rgba(16,32,64,0.08);
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
            border: 2px solid #e2e8f0;
        }
        
        .parking-card-item:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(16,32,64,0.15);
        }
        
        .parking-img-container {
            width: 100%;
            height: 180px;
            overflow: hidden;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        
        .parking-img-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .parking-img-placeholder {
            color: #ffffff;
            font-size: 3em;
            font-weight: 300;
        }
        
        .parking-card-content {
            padding: 16px;
        }
        
        .parking-card-title {
            font-size: 1.1em;
            font-weight: 700;
            color: var(--accent);
            margin: 0 0 8px 0;
        }
        
        .parking-card-address {
            font-size: 0.95em;
            color: var(--muted);
            margin: 0 0 12px 0;
            display: flex;
            align-items: flex-start;
            gap: 6px;
        }
        
        .btn-eliminar { 
            background: linear-gradient(90deg,#dc3545,#a71d2a); 
            color: #fff; 
            border: none; 
            padding: 10px 16px; 
            border-radius: 10px; 
            cursor: pointer; 
            font-size: 0.95em; 
            font-weight: 600; 
            box-shadow: 0 2px 8px rgba(16,32,64,0.07); 
            transition: background 0.18s, transform 0.15s; 
            width: 100%; 
            margin-top: 4px; 
        }
        .btn-eliminar:hover { 
            background: linear-gradient(90deg,#a71d2a,#dc3545); 
            transform: translateY(-2px) scale(1.02); 
        }
        
        .no-parkings-msg {
            text-align: center;
            padding: 40px 20px;
            color: var(--muted);
            font-size: 1.05em;
        }
        
        @media (max-width:640px){
            .container{max-width:98vw;padding:12px 2vw;}
            .parkings-grid {
                grid-template-columns: 1fr;
                gap: 16px;
            }
            .parking-img-container {
                height: 160px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Registrar y Gestionar Parqueaderos</h1>
        <p class="menu-admin">
            <a href="dashboard.php">Dashboard</a> | 
            <a href="gestion_espacios.php">Gestionar Espacios</a> |
            <a href="ver_reservas.php">Ver Reservas</a> |
            <a href="../logout.php">Cerrar Sesión</a>
        </p>

        <?php if ($mensaje): ?>
            <div class="alerta <?php echo strpos($mensaje, '✅') !== false ? 'exito' : 'error'; ?>">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <div class="form-registro">
            <h2>Registrar Nuevo Parqueadero</h2>
            <form action="registrar_parqueadero.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="accion" value="registrar_parking">
                
                <label for="nombre_parqueadero">Nombre del Parqueadero:</label>
                <input type="text" id="nombre_parqueadero" name="nombre_parqueadero" required>
                
                <label for="direccion">Dirección/Ubicación:</label>
                <input type="text" id="direccion" name="direccion" required>
                
                <label for="imagen_parqueadero">Imagen del Parqueadero (Opcional):</label>
                <input type="file" id="imagen_parqueadero" name="imagen_parqueadero" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp">
                <small style="color: var(--muted); font-size: 0.9em; display: block; margin-top: -10px; margin-bottom: 12px;">
                    📸 Formatos permitidos: JPG, PNG, GIF, WEBP
                </small>
                
                <button type="submit">Registrar Parqueadero</button>
            </form>
        </div>

        <div class="listado-parkings">
            <h2>Mis Parqueaderos Activos</h2>
            
            <?php 
            // Verificación de seguridad y listado
            if ($resultado_parkings !== FALSE && $resultado_parkings->num_rows > 0): 
            ?>
                <div class="parkings-grid">
                    <?php while($parking = $resultado_parkings->fetch_assoc()): ?>
                        <div class="parking-card-item">
                            <div class="parking-img-container">
                                <?php if (!empty($parking['imagen']) && file_exists("../uploads/parqueaderos/" . $parking['imagen'])): ?>
                                    <img src="../uploads/parqueaderos/<?php echo htmlspecialchars($parking['imagen']); ?>" alt="<?php echo htmlspecialchars($parking['nombre_parqueadero']); ?>">
                                <?php else: ?>
                                    <div class="parking-img-placeholder"><img src="https://senalescuberos.es/510-large_default/senal-p-parking.jpg" alt=""></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="parking-card-content">
                                <h3 class="parking-card-title">
                                    <?php echo htmlspecialchars($parking['nombre_parqueadero']); ?>
                                </h3>
                                <p class="parking-card-address">
                                    <span>📍</span>
                                    <span><?php echo htmlspecialchars($parking['direccion']); ?></span>
                                </p>
                                
                                <form action="registrar_parqueadero.php" method="POST" onsubmit="return confirm('¿Estás seguro de DESACTIVAR el parqueadero <?php echo htmlspecialchars($parking['nombre_parqueadero']); ?>? Esto también desactivará todos sus puestos y no podrá volver a reservarse. RECUERDA: Todos los puestos deben estar desocupados.');">
                                    <input type="hidden" name="accion" value="eliminar_parking">
                                    <input type="hidden" name="parqueadero_id" value="<?php echo $parking['id']; ?>">
                                    <button type="submit" class="btn-eliminar">Desactivar Parqueadero</button>
                                </form>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="no-parkings-msg">
                    <p>📭 Aún no has registrado ningún parqueadero activo.</p>
                    <p>Usa el formulario de arriba para empezar.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>