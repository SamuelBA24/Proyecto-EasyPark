<?php
session_start();
// Verificar si el usuario está logueado y es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.php"); 
    exit();
}
include '../conexion.php'; 

$admin_id = $_SESSION['usuario_id'];
$mensaje = "";

// =========================================================
// 1. Lógica para manejar la acción de "Finalizar Reserva"
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'finalizar_reserva') {
    
    $reserva_id = $conn->real_escape_string($_POST['reserva_id']);
    $espacio_id = $conn->real_escape_string($_POST['espacio_id']);

    // Iniciar transacción para asegurar que ambos updates se ejecuten
    $conn->begin_transaction();
    $exito = true;

    // 1. Actualizar el estado de la reserva a 'finalizada'
    $sql_update_reserva = "UPDATE reservas SET estado_reserva = 'finalizada', fecha_hora_salida_real = NOW() WHERE id = '$reserva_id' AND estado_reserva = 'confirmada'";
    
    if (!$conn->query($sql_update_reserva)) {
        $exito = false;
        $mensaje = "❌ Error al finalizar la reserva: " . $conn->error;
    }

    // 2. Actualizar el estado del espacio a 'disponible'
    if ($exito) {
        $sql_update_espacio = "UPDATE espacios SET estado = 'disponible' WHERE id = '$espacio_id'";
        if (!$conn->query($sql_update_espacio)) {
            $exito = false;
            $mensaje = "❌ Error al liberar el espacio: " . $conn->error;
        }
    }

    if ($exito) {
        $conn->commit();
        $mensaje = "✅ Reserva finalizada y espacio liberado con éxito.";
    } else {
        $conn->rollback();
        // El mensaje ya fue generado en los errores anteriores
    }
}


// =========================================================
// 2. OBTENER LAS RESERVAS QUE PERTENECEN A LOS PARQUEADEROS DEL ADMIN
// =========================================================
// Filtra solo por los parqueaderos donde p.admin_id coincide con el admin logueado
$sql_reservas = "SELECT 
    r.id AS reserva_id, 
    r.placa_vehiculo, 
    r.fecha_hora_entrada_reservada, 
    r.fecha_hora_salida_reservada, 
    r.estado_reserva, 
    r.espacio_id,
    e.numero_espacio,
    p.nombre_parqueadero,
    u.nombre AS nombre_cliente
FROM reservas r
JOIN espacios e ON r.espacio_id = e.id
JOIN parqueaderos p ON e.parqueadero_id = p.id
JOIN usuarios u ON r.usuario_id = u.id
WHERE p.admin_id = '$admin_id'
ORDER BY r.fecha_hora_entrada_reservada DESC";

$resultado_reservas = $conn->query($sql_reservas);

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Ver Reservas</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #1266d5;
            --accent-2: #0b5ed7;
            --muted: #6b7280;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
            --success: #24b358;
            --danger: #dc3545;
            --warning: #f9e5c7;
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        html,body{height:100%}
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 980px;
            margin: 32px auto 0 auto;
            background: var(--card);
            padding: 38px 32px 28px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }
    .header-row {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        margin-bottom: 18px;
    }
    .header-row img {
        height: 38px;
        width: auto;
        display: block;
        margin: 0 10px 0 0;
    }
    .header-title {
        font-size: 1.08em;
        font-weight: 700;
        color: var(--accent);
        margin: 0;
        line-height: 1;
        display: flex;
        align-items: center;
    }
        h1 {
            color: var(--accent);
            font-size: 1.6em;
            font-weight: 700;
            text-align: center;
            margin:0;
            letter-spacing: 0.5px;
        }
        .menu-admin {
            text-align: center;
            margin-bottom: 18px;
        }
        .menu-admin a {
            margin: 0 10px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 8px;
            transition: background 0.18s;
        }
        .menu-admin a:hover {
            background: #f0f8ff;
            text-decoration: underline;
        }
        .alerta {
            padding: 12px 0;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: 500;
            text-align: center;
            font-size: 1em;
        }
        .exito {
            background-color: #eafbe7;
            color: #1e8f40;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #fff0f0;
            color: #dc3545;
            border: 1px solid #f5c6cb;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            background: #f6f8fa;
            border-radius: 14px;
            box-shadow: 0 2px 8px rgba(16,32,64,0.04);
            overflow: hidden;
        }
        th, td {
            border: none;
            padding: 12px 8px;
            text-align: center;
            font-size: 1em;
        }
        th {
            background: linear-gradient(90deg,var(--accent),var(--accent-2));
            color: #fff;
            font-weight: 600;
            font-size: 1em;
        }
        tr {
            border-bottom: 1px solid #e2e8f0;
        }
        .confirmada {
            background-color: #eafbe7;
            color: #1e8f40;
        }
        .finalizada {
            background-color: #fff0f0;
            color: #9c4500;
        }
        .btn-finalizar {
            background: linear-gradient(90deg,var(--danger),#a71d2a);
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.98em;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            transition: background 0.18s, transform 0.15s;
        }
        .btn-finalizar:hover {
            background: linear-gradient(90deg,#a71d2a,var(--danger));
            transform: translateY(-2px) scale(1.04);
        }
        @media (max-width:900px){
            .container{max-width:98vw;padding:12px 2vw;}
        }
        @media (max-width:640px){
            .container{padding:8px 2vw;}
            h1{font-size:1em;}
            th,td{padding:6px 1vw;font-size:0.95em;}
            table{font-size:0.98em;}
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-row">
            <img src="../img/logo2.png" alt="EasyPark" style="height:70px;width:auto;display:block;margin-right:10px;" />
            <span class="header-title">Control de Reservas y Tráfico</span>
        </div>
        <p class="menu-admin">
            <a href="dashboard.php">Dashboard</a> | 
            <a href="gestion_espacios.php">Gestionar Espacios</a> |
            <a href="../logout.php">Cerrar Sesión</a>
        </p>
        
        <?php if ($mensaje): ?>
            <div class="alerta <?php echo strpos($mensaje, '✅') !== false ? 'exito' : 'error'; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>

        <?php if ($resultado_reservas->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Parqueadero</th>
                        <th>Puesto</th>
                        <th>Placa Vehículo</th>
                        <th>Cliente</th>
                        <th>Entrada (Reservada)</th>
                        <th>Salida (Reservada)</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($reserva = $resultado_reservas->fetch_assoc()): ?>
                        <tr class="<?php echo htmlspecialchars($reserva['estado_reserva']); ?>">
                            <td><?php echo htmlspecialchars($reserva['nombre_parqueadero']); ?></td>
                            <td>**<?php echo htmlspecialchars($reserva['numero_espacio']); ?>**</td>
                            <td>**<?php echo htmlspecialchars($reserva['placa_vehiculo']); ?>**</td>
                            <td><?php echo htmlspecialchars($reserva['nombre_cliente']); ?></td>
                            <td><?php echo date("d/m/Y H:i", strtotime($reserva['fecha_hora_entrada_reservada'])); ?></td>
                            <td><?php echo date("d/m/Y H:i", strtotime($reserva['fecha_hora_salida_reservada'])); ?></td>
                            <td>**<?php echo strtoupper(htmlspecialchars($reserva['estado_reserva'])); ?>**</td>
                            <td>
                                <?php if ($reserva['estado_reserva'] == 'confirmada'): ?>
                                    <form method="POST" action="ver_reservas.php" onsubmit="return confirm('¿Confirma que el vehículo con placa <?php echo $reserva['placa_vehiculo']; ?> está saliendo y se debe liberar el puesto?');">
                                        <input type="hidden" name="accion" value="finalizar_reserva">
                                        <input type="hidden" name="reserva_id" value="<?php echo $reserva['reserva_id']; ?>">
                                        <input type="hidden" name="espacio_id" value="<?php echo $reserva['espacio_id']; ?>">
                                        <button type="submit" class="btn-finalizar">Finalizar y Liberar</button>
                                    </form>
                                <?php else: ?>
                                    --
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center; padding: 20px; border: 1px dashed #ccc; margin-top: 30px;">
                No hay reservas registradas o activas para ninguno de tus parqueaderos.
            </p>
        <?php endif; ?>
    </div>
</body>
</html>