<?php
session_start();
// Asegurar que solo el admin acceda
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.php"); 
    exit();
}
include '../conexion.php'; 

$admin_id = $_SESSION['usuario_id'];
$mensaje = "";
$parqueadero_id_seleccionado = null;
$nombre_parqueadero_seleccionado = "";
$espacios = [];

// =========================================================
// 1. MANEJAR INSERCIÓN DE NUEVO ESPACIO
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'agregar_espacio') {
    // Escapar y validar inputs
    $parqueadero_id_seleccionado = $conn->real_escape_string($_POST['parqueadero_id']);
    $numero_espacio = $conn->real_escape_string($_POST['numero_espacio']);

    if (!empty($parqueadero_id_seleccionado) && !empty($numero_espacio)) {
        // Verificar que el espacio no exista ya en ese parqueadero
        // *Añadida verificación de ACTIVO para evitar duplicados en puestos desactivados*
        $sql_check = "SELECT id FROM espacios WHERE parqueadero_id = '$parqueadero_id_seleccionado' AND numero_espacio = '$numero_espacio' AND activo = TRUE";
        $result_check = $conn->query($sql_check);

        if ($result_check->num_rows == 0) {
            // Se asume que 'activo' es TRUE por defecto
            $sql_insert = "INSERT INTO espacios (parqueadero_id, numero_espacio) VALUES ('$parqueadero_id_seleccionado', '$numero_espacio')";
            
            if ($conn->query($sql_insert) === TRUE) {
                $mensaje = "✅ Espacio N° $numero_espacio agregado con éxito.";
            } else {
                $mensaje = "❌ Error al agregar espacio: " . $conn->error;
            }
        } else {
            $mensaje = "❌ Error: El espacio N° $numero_espacio ya existe y está activo en este parqueadero.";
        }
    } else {
        $mensaje = "❌ Error: Debe seleccionar un parqueadero e ingresar un número de espacio.";
    }
}

// =========================================================
// 2. MANEJAR DESACTIVACIÓN DE ESPACIO (CORRECCIÓN CRÍTICA: Se usa UPDATE)
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'eliminar_espacio') {
    $espacio_a_desactivar = $conn->real_escape_string($_POST['espacio_id']);
    $parqueadero_id_seleccionado = $conn->real_escape_string($_POST['parqueadero_id']);

    // 1. Verificar si el espacio tiene reservas confirmadas/activas
    $sql_check_reserva = "SELECT id FROM reservas WHERE espacio_id = '$espacio_a_desactivar' AND estado_reserva = 'confirmada'";
    $result_check_reserva = $conn->query($sql_check_reserva);

    if ($result_check_reserva->num_rows > 0) {
        $mensaje = "❌ Error: No se puede eliminar el puesto. Tiene una reserva activa.";
    } else {
        // 2. DESACTIVAR el espacio (cambia 'activo' a FALSE) en lugar de DELETE
        $sql_update = "UPDATE espacios SET activo = FALSE WHERE id = '$espacio_a_desactivar'";
        
        if ($conn->query($sql_update) === TRUE) {
            $mensaje = "✅ Espacio desactivado con éxito. Ya no será visible ni reservable.";
        } else {
            $mensaje = "❌ Error al desactivar el espacio: " . $conn->error;
        }
    }
}

// =========================================================
// 3. OBTENER LOS PARQUEADEROS DEL ADMINISTRADOR LOGUEADO
// =========================================================
$sql_parkings = "SELECT id, nombre_parqueadero FROM parqueaderos WHERE admin_id = '$admin_id'";
$resultado_parkings = $conn->query($sql_parkings);

$parkings = [];
if ($resultado_parkings->num_rows > 0) {
    while($row = $resultado_parkings->fetch_assoc()) {
        $parkings[] = $row;
    }
}

// =========================================================
// 4. OBTENER ESPACIOS DEL PARQUEADERO SELECCIONADO (CORRECCIÓN CRÍTICA: Se filtra por activo=TRUE)
// =========================================================
// Priorizar el ID del POST (después de agregar/eliminar), si no el primero
if (isset($_POST['parqueadero_id']) && $_POST['parqueadero_id'] != '') {
    $parqueadero_id_seleccionado = $conn->real_escape_string($_POST['parqueadero_id']);
} elseif (!empty($parkings)) {
    $parqueadero_id_seleccionado = $parkings[0]['id'];
}

if ($parqueadero_id_seleccionado) {
    // Encontrar el nombre del parqueadero seleccionado
    foreach ($parkings as $p) {
        if ($p['id'] == $parqueadero_id_seleccionado) {
            $nombre_parqueadero_seleccionado = $p['nombre_parqueadero'];
            break;
        }
    }

    // Obtener los espacios para el parqueadero seleccionado, solo si están activos
    $sql_espacios = "SELECT 
        e.id, 
        e.numero_espacio, 
        e.estado, 
        r.placa_vehiculo,
        r.fecha_hora_salida_reservada
    FROM espacios e
    LEFT JOIN reservas r ON e.id = r.espacio_id AND r.estado_reserva = 'confirmada'
    WHERE e.parqueadero_id = '$parqueadero_id_seleccionado' AND e.activo = TRUE 
    ORDER BY e.numero_espacio ASC";

    $resultado_espacios = $conn->query($sql_espacios);
    while($fila = $resultado_espacios->fetch_assoc()) {
        $espacios[] = $fila;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Gestión de Espacios</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #1266d5;
            --accent-2: #0b5ed7;
            --muted: #6b7280;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
            --success: #24b358;
            --danger: #dc3545;
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        html,body{height:100%}
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 980px;
            margin: 32px auto 0 auto;
            background: var(--card);
            padding: 38px 32px 28px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }
        .header-row{
            display:flex;
            align-items:center;
            justify-content:center;
            gap:12px;
            margin-bottom:18px;
        }
        .header-row img{
            height:38px;
            width:auto;
            display:block;
            margin-right:10px;
        }
        h1 {
            color: var(--accent);
            font-size: 1.6em;
            font-weight: 700;
            text-align: center;
            margin:0;
            letter-spacing: 0.5px;
        }
        .menu-admin {
            text-align: center;
            margin-bottom: 18px;
        }
        .menu-admin a {
            margin: 0 10px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 8px;
            transition: background 0.18s;
        }
        .menu-admin a:hover {
            background: #f0f8ff;
            text-decoration: underline;
        }
        .alerta {
            padding: 12px 0;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: 500;
            text-align: center;
            font-size: 1em;
        }
        .exito {
            background-color: #eafbe7;
            color: #1e8f40;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #fff0f0;
            color: #dc3545;
            border: 1px solid #f5c6cb;
        }

        .select-parking, .add-space {
            background: #f6f8fa;
            padding: 18px 18px 12px 18px;
            border-radius: 14px;
            margin-bottom: 22px;
            box-shadow: 0 2px 8px rgba(16,32,64,0.04);
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .select-parking label, .add-space label {
            font-weight: 500;
            color: #1a2330;
            margin-bottom: 6px;
            text-align: left;
            width: 100%;
        }
        .select-parking select, .add-space input {
            padding: 10px 12px;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            margin-bottom: 12px;
            font-size: 1em;
            background: #f8fafc;
            color: #1a2330;
            width: 100%;
            max-width: 320px;
            box-sizing: border-box;
            transition: border-color 0.2s;
        }
        .select-parking select:focus, .add-space input:focus {
            border-color: var(--accent);
            outline: none;
        }
        .select-parking button, .add-space button {
            padding: 10px 22px;
            background: linear-gradient(90deg,var(--accent),var(--accent-2));
            color: #f4f4f4;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1em;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            margin-top: 4px;
            transition: background 0.2s, transform 0.15s;
        }
        .select-parking button:hover, .add-space button:hover {
            background: linear-gradient(90deg,#0b5ed7,#1266d5);
            transform: translateY(-2px) scale(1.02);
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            background: #f6f8fa;
            border-radius: 14px;
            box-shadow: 0 2px 8px rgba(16,32,64,0.04);
            overflow: hidden;
        }
        th, td {
            border: none;
            padding: 12px 8px;
            text-align: center;
            font-size: 1em;
        }
        th {
            background: linear-gradient(90deg,var(--accent),var(--accent-2));
            color: #fff;
            font-weight: 600;
            font-size: 1em;
        }
        tr {
            border-bottom: 1px solid #e2e8f0;
        }
        .disponible {
            background-color: #eafbe7;
        }
        .ocupado {
            background-color: #fff0f0;
        }
        .btn-eliminar {
            background: linear-gradient(90deg,var(--danger),#a71d2a);
            color: #fff;
            border: none;
            padding: 8px 16px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 0.98em;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            transition: background 0.18s, transform 0.15s;
        }
        .btn-eliminar:hover {
            background: linear-gradient(90deg,#a71d2a,var(--danger));
            transform: translateY(-2px) scale(1.04);
        }
        @media (max-width:900px){
            .container{max-width:98vw;padding:12px 2vw;}
        }
        @media (max-width:640px){
            .container{padding:8px 2vw;}
            h1{font-size:1em;}
            .select-parking, .add-space{padding:8px 2vw;}
            th,td{padding:6px 1vw;font-size:0.95em;}
            table{font-size:0.98em;}
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-row">
            <img src="../img/logo1.png" alt="EasyPark" style="height:60px;width:auto;display:block;margin-right:10px;" />
            <h1 style="font-size:1.15em;margin:0;">Gestión de Espacios: <?php echo htmlspecialchars($nombre_parqueadero_seleccionado ?: 'Seleccione un Parqueadero'); ?></h1>
        </div>
        <p class="menu-admin">
            <a href="dashboard.php">Dashboard</a> | 
            <a href="registrar_parqueadero.php">Registrar Parqueadero</a> |
            <a href="ver_reservas.php">Ver Reservas</a> |
            <a href="../logout.php">Cerrar Sesión</a>
        </p>

        <?php if ($mensaje): ?>
            <div class="alerta <?php echo strpos($mensaje, '✅') !== false ? 'exito' : 'error'; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>

        <?php if (empty($parkings)): ?>
            <div class="alerta error">
                Aún no has registrado ningún parqueadero. Por favor, <a href="registrar_parqueadero.php">registra tu primer parqueadero</a> para empezar a añadir espacios.
            </div>
        <?php else: ?>
            
            <div class="select-parking">
                <form action="gestion_espacios.php" method="POST">
                    <label for="parqueadero_id">Seleccionar Parqueadero:</label>
                    <select id="parqueadero_id" name="parqueadero_id" onchange="this.form.submit()">
                        <?php foreach ($parkings as $p): ?>
                            <option value="<?php echo $p['id']; ?>" <?php echo $p['id'] == $parqueadero_id_seleccionado ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($p['nombre_parqueadero']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <noscript><button type="submit">Ver Espacios</button></noscript> 
                </form>
            </div>

            <?php if ($parqueadero_id_seleccionado): ?>
                
                <div class="add-space">
                    <h3>Añadir Nuevo Espacio</h3>
                    <form action="gestion_espacios.php" method="POST">
                        <input type="hidden" name="accion" value="agregar_espacio">
                        <input type="hidden" name="parqueadero_id" value="<?php echo $parqueadero_id_seleccionado; ?>">
                        <label for="numero_espacio">Número de Espacio:</label>
                        <input type="text" id="numero_espacio" name="numero_espacio" placeholder="Ej: A1, 101, Moto 5" required>
                        <button type="submit">Agregar Espacio a <?php echo $nombre_parqueadero_seleccionado; ?></button>
                    </form>
                </div>

                <h3>Puestos de Parqueo Registrados</h3>
                <table>
                    <thead>
                        <tr>
                            <th>N° Espacio</th>
                            <th>Estado</th>
                            <th>Placa (Reserva Activa)</th>
                            <th>Salida Reservada</th>
                            <th>Acción</th> 
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($espacios)): ?>
                            <?php foreach ($espacios as $e): ?>
                                <tr class="<?php echo $e['estado'] == 'disponible' ? 'disponible' : 'ocupado'; ?>">
                                    <td><strong><?php echo htmlspecialchars($e['numero_espacio']); ?></strong></td>
                                    <td><?php echo strtoupper(htmlspecialchars($e['estado'])); ?></td>
                                    <td><?php echo htmlspecialchars($e['placa_vehiculo'] ?: 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($e['fecha_hora_salida_reservada'] ?: 'N/A'); ?></td>
                                    <td>
                                        <?php if ($e['estado'] == 'disponible'): ?>
                                            <form action="gestion_espacios.php" method="POST" onsubmit="return confirm('¿Está seguro de DESACTIVAR el espacio <?php echo $e['numero_espacio']; ?>? Ya no se podrá volver a reservar.');">
                                                <input type="hidden" name="accion" value="eliminar_espacio">
                                                <input type="hidden" name="espacio_id" value="<?php echo $e['id']; ?>">
                                                <input type="hidden" name="parqueadero_id" value="<?php echo $parqueadero_id_seleccionado; ?>">
                                                <button type="submit" class="btn-eliminar">Desactivar</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="color: gray;">Ocupado</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td colspan="5">No hay espacios registrados aún para este parqueadero.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>