<?php
session_start();
// Verificar si el usuario está logueado y es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.php"); // Redirigir si no es admin
    exit();
}
include '../conexion.php'; 

$admin_id = $_SESSION['usuario_id'];
$resumen = [];

// =========================================================
// Lógica para obtener el resumen de parqueaderos y espacios
// =========================================================

// Consulta 1: Contar los parqueaderos registrados por este admin (FILTRAR POR ACTIVO)
$sql_parqueaderos = "SELECT COUNT(id) AS total_parqueaderos FROM parqueaderos WHERE admin_id = '$admin_id' AND activo = TRUE";
$res_parqueaderos = $conn->query($sql_parqueaderos)->fetch_assoc();
$resumen['total_parqueaderos'] = $res_parqueaderos['total_parqueaderos'];

// Consulta 2: Obtener el total de espacios y los disponibles en TODOS sus parqueaderos
// Filtra solo puestos activos (operacionales)
$sql_espacios = "SELECT 
    COUNT(e.id) AS total_espacios,
    SUM(CASE WHEN e.estado = 'disponible' THEN 1 ELSE 0 END) AS disponibles
FROM espacios e
JOIN parqueaderos p ON e.parqueadero_id = p.id
WHERE p.admin_id = '$admin_id' AND e.activo = TRUE"; 

$res_espacios = $conn->query($sql_espacios)->fetch_assoc();
$resumen['total_espacios'] = (int)$res_espacios['total_espacios'];
$resumen['disponibles'] = (int)$res_espacios['disponibles'];
// El cálculo de ocupados se hace restando.
$resumen['ocupados'] = $resumen['total_espacios'] - $resumen['disponibles'];


// Consulta 3: Obtener el total de RESERVAS CONFIRMADAS (Tráfico Real/Esperado)
$sql_reservas_activas = "SELECT 
    COUNT(r.id) AS total_reservas_activas
FROM reservas r
JOIN espacios e ON r.espacio_id = e.id
JOIN parqueaderos p ON e.parqueadero_id = p.id
WHERE p.admin_id = '$admin_id' AND r.estado_reserva = 'confirmada'";

$res_reservas_activas = $conn->query($sql_reservas_activas)->fetch_assoc();
$resumen['reservas_activas'] = (int)$res_reservas_activas['total_reservas_activas'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - EasyPark</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; background-color: #f4f7fc; color: #34495e; }
        .container { max-width: 1200px; margin: 0 auto; }
        .admin-header{display:flex;align-items:center;gap:16px;justify-content:flex-start;margin-bottom:12px}
        .admin-header img{height:72px;width:auto}
        h1 { color: #003366; border-bottom: 3px solid #007bff; padding-bottom: 10px; font-weight: 600; }
        .welcome { font-size: 1.2em; margin-bottom: 25px; }

        /* --- Menú de Navegación --- */
        .menu-admin { background-color: #007bff; padding: 15px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); }
        .menu-admin ul { list-style: none; padding: 0; margin: 0; display: flex; justify-content: space-around; }
        .menu-admin a { color: white; text-decoration: none; font-weight: bold; padding: 10px 15px; transition: background-color 0.3s; border-radius: 5px; }
        .menu-admin a:hover { background-color: #0056b3; }

        /* --- Tarjetas de Resumen --- */
        .resumen-cards { display: flex; justify-content: space-between; gap: 20px; flex-wrap: wrap; }
        /* Aumentado el ancho para que quepan 4 tarjetas en la fila */
        .card { background: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08); width: 22%; min-width: 200px; text-align: left; }
        .card h3 { color: #007bff; margin-top: 0; font-size: 1.2em; border-bottom: 1px solid #eee; padding-bottom: 5px; }
        .card .valor { font-size: 2.2em; font-weight: 700; margin: 5px 0; }
        .card.parqueaderos .valor { color: #f39c12; }
        .card.disponibles .valor { color: #2ecc71; } 
        .card.reservas .valor { color: #e74c3c; } /* Rojo para las activas */
        .card.total .valor { color: #3498db; }
    </style>
</head>
<body>
    <div class="container">
        <div class="admin-header">
            <img src="../img/logo1.png" alt="EasyPark" />
            <div>
                <h1>Dashboard Administrativo</h1>
                <p class="welcome">Bienvenido, **<?php echo htmlspecialchars($_SESSION['nombre']); ?>** (Rol: Administrador).</p>
            </div>
        </div>

        <div class="menu-admin">
            <ul>
                <li><a href="registrar_parqueadero.php">Registrar Nuevo Parqueadero</a></li>
                <li><a href="gestion_espacios.php">Gestionar Espacios</a></li>
                <li><a href="ver_reservas.php">Ver Reservas y Tráfico</a></li>
                <li><a href="../logout.php">Cerrar Sesión</a></li>
            </ul>
        </div>
        
        <h2>Resumen Operacional</h2>
        <div class="resumen-cards">
            
            <div class="card parqueaderos">
                <h3>Mis Parqueaderos</h3>
                <div class="valor"><?php echo number_format($resumen['total_parqueaderos']); ?></div>
                <p>Negocios activos.</p>
            </div>

            <div class="card total">
                <h3>Espacios Totales</h3>
                <div class="valor"><?php echo number_format($resumen['total_espacios']); ?></div>
                <p>Puestos operacionales.</p>
            </div>
            
            <div class="card disponibles">
                <h3>Disponibles HOY</h3>
                <div class="valor"><?php echo number_format($resumen['disponibles']); ?></div>
                <p>Puestos listos para reservar.</p>
            </div>

            <div class="card reservas">
                <h3>Reservas Activas</h3>
                <div class="valor"><?php echo number_format($resumen['reservas_activas']); ?></div>
                <p>Reservas confirmadas actualmente.</p>
            </div>

        </div>
        
        <h2 style="margin-top: 40px;">Acciones Rápidas</h2>
        <p>Utiliza el menú superior o estos enlaces para tus tareas diarias:</p>
        <div class="menu-admin" style="background-color: #f8f8f8;">
            <ul>
                <li><a href="gestion_espacios.php" style="color: #003366;">Añadir/Desactivar Puestos</a></li>
                <li><a href="ver_reservas.php" style="color: #003366;">Control de Entradas/Salidas</a></li>
            </ul>
        </div>
    </div>
</body>
</html>