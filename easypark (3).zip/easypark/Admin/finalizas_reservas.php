<?php
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}
include '../conexion.php'; 

$reserva_id = isset($_GET['id']) ? $conn->real_escape_string($_GET['id']) : null;

if (!$reserva_id) {
    header("Location: ver_reservas.php?msg=" . urlencode("Error: ID de reserva no especificado."));
    exit();
}

// 1. Obtener el espacio_id asociado a esta reserva antes de actualizarla
$sql_get_espacio = "SELECT espacio_id FROM reservas WHERE id = '$reserva_id' AND estado_reserva IN ('pendiente', 'confirmada')";
$resultado_get_espacio = $conn->query($sql_get_espacio);

if ($resultado_get_espacio->num_rows == 0) {
    $conn->close();
    header("Location: ver_reservas.php?msg=" . urlencode("Error: Reserva no encontrada o ya finalizada."));
    exit();
}

$fila = $resultado_get_espacio->fetch_assoc();
$espacio_id = $fila['espacio_id'];

// Iniciar Transacción
$conn->begin_transaction();
$mensaje_final = "";

try {
    // 2. Actualizar la reserva a 'finalizada'
    $sql_update_reserva = "UPDATE reservas SET estado_reserva = 'finalizada' WHERE id = '$reserva_id'";
    if ($conn->query($sql_update_reserva) === FALSE) {
        throw new Exception("Error al finalizar la reserva.");
    }
    
    // 3. Liberar el espacio de parqueo, poniéndolo en 'disponible'
    $sql_update_espacio = "UPDATE espacios SET estado = 'disponible' WHERE id = '$espacio_id'";
    if ($conn->query($sql_update_espacio) === FALSE) {
        throw new Exception("Error al liberar el espacio.");
    }

    // 4. Si todo es exitoso, confirmar
    $conn->commit();
    $mensaje_final = "✅ Reserva N° $reserva_id finalizada y espacio $espacio_id liberado correctamente.";

} catch (Exception $e) {
    // Revertir si algo falla
    $conn->rollback();
    $mensaje_final = "❌ Error en la transacción: " . $e->getMessage();
}

$conn->close();

// Redirigir de vuelta a la lista con un mensaje
header("Location: ver_reservas.php?msg=" . urlencode($mensaje_final));
exit();
?>