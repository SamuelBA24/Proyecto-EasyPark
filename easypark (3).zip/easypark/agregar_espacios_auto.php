<?php
// Script para agregar varios espacios a todos los parqueaderos activos
// Uso: abrir en navegador: http://localhost/easypark/agregar_espacios_auto.php
// Agrega espacios del 1 al N si faltan, sin duplicar y marcados como disponibles/activos

include 'conexion.php';

// Parámetros
$espaciosObjetivoPorParking = 20; // ajustar si quieres más/menos

function respuesta($msg) { echo '<p>'.$msg.'</p>'; }

// Obtener parqueaderos activos
$sql_parks = "SELECT id, nombre_parqueadero FROM parqueaderos WHERE activo = TRUE";
$res_parks = $conn->query($sql_parks);

if ($res_parks === false) {
    respuesta('❌ Error consultando parqueaderos: ' . $conn->error);
    exit;
}

if ($res_parks->num_rows === 0) {
    respuesta('📭 No hay parqueaderos activos.');
    exit;
}

respuesta('<b>Agregando espacios a parqueaderos activos…</b>');

while ($p = $res_parks->fetch_assoc()) {
    $pid = (int)$p['id'];
    $nombre = htmlspecialchars($p['nombre_parqueadero']);

    // Obtener espacios existentes (activos) para conocer los números ya usados
    $existentes = [];
    $sql_exist = "SELECT numero_espacio FROM espacios WHERE parqueadero_id = '$pid' AND activo = TRUE";
    $res_exist = $conn->query($sql_exist);
    if ($res_exist !== false) {
        while ($row = $res_exist->fetch_assoc()) {
            $existentes[(int)$row['numero_espacio']] = true;
        }
    }

    $agregados = 0;
    for ($n = 1; $n <= $espaciosObjetivoPorParking; $n++) {
        if (!isset($existentes[$n])) {
            $sql_ins = "INSERT INTO espacios (parqueadero_id, numero_espacio, estado, activo) VALUES ('$pid', '$n', 'disponible', TRUE)";
            if ($conn->query($sql_ins)) {
                $agregados++;
            } else {
                respuesta('⚠️ Error agregando espacio '.$n.' en '.$nombre.': '.$conn->error);
            }
        }
    }

    if ($agregados > 0) {
        respuesta('✅ '.$nombre.': '.$agregados.' espacio(s) agregado(s).');
    } else {
        respuesta('ℹ️ '.$nombre.': ya tenía al menos '.$espaciosObjetivoPorParking.' espacios.');
    }
}

respuesta('<b>Proceso finalizado.</b>');

$conn->close();
?>


