-- Script para agregar soporte de métodos de pago a EasyPark
-- Ejecutar en phpMyAdmin

-- 1. Agregar campo de método de pago a reservas
ALTER TABLE reservas 
ADD COLUMN metodo_pago ENUM('efectivo', 'payu') DEFAULT 'efectivo' COMMENT 'Método de pago utilizado',
ADD COLUMN estado_pago ENUM('pendiente', 'pagado', 'fallido', 'cancelado') DEFAULT 'pendiente' COMMENT 'Estado del pago',
ADD COLUMN referencia_pago VARCHAR(100) NULL COMMENT 'Referencia de pago de PayU',
ADD COLUMN transaction_id VARCHAR(100) NULL COMMENT 'ID de transacción de PayU',
ADD COLUMN monto_total DECIMAL(10,2) NULL COMMENT 'Monto total pagado',
ADD COLUMN fecha_pago TIMESTAMP NULL COMMENT 'Fecha y hora del pago';

-- 2. Crear tabla para métodos de pago disponibles
CREATE TABLE IF NOT EXISTS metodos_pago (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) NOT NULL UNIQUE,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    logo_url VARCHAR(255),
    activo BOOLEAN DEFAULT TRUE,
    orden INT DEFAULT 0,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Insertar métodos de pago por defecto
INSERT INTO metodos_pago (codigo, nombre, descripcion, logo_url, activo, orden) VALUES 
('efectivo', 'Efectivo', 'Pago en efectivo al llegar al parqueadero', NULL, TRUE, 1),
('payu', 'PayU', 'Pago seguro con tarjeta de crédito o débito', 'https://www.payulatam.com/img/logos/payu_logo.png', TRUE, 2);

-- 4. Crear tabla para transacciones de pago (historial detallado)
CREATE TABLE IF NOT EXISTS transacciones_pago (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reserva_id INT NOT NULL,
    metodo_pago VARCHAR(50) NOT NULL,
    referencia_pago VARCHAR(100) NOT NULL,
    transaction_id VARCHAR(100),
    monto DECIMAL(10,2) NOT NULL,
    moneda VARCHAR(3) DEFAULT 'COP',
    estado VARCHAR(50) NOT NULL,
    respuesta_payu TEXT,
    fecha_transaccion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (reserva_id) REFERENCES reservas(id) ON DELETE CASCADE
);

-- 5. Crear índices para mejorar rendimiento
CREATE INDEX idx_reservas_metodo_pago ON reservas(metodo_pago);
CREATE INDEX idx_reservas_estado_pago ON reservas(estado_pago);
CREATE INDEX idx_reservas_referencia_pago ON reservas(referencia_pago);
CREATE INDEX idx_transacciones_reserva ON transacciones_pago(reserva_id);
CREATE INDEX idx_transacciones_referencia ON transacciones_pago(referencia_pago);

-- 6. Actualizar reservas existentes
UPDATE reservas SET 
    metodo_pago = 'efectivo',
    estado_pago = 'pagado',
    monto_total = (
        SELECT p.tarifa_hora * TIMESTAMPDIFF(HOUR, r.fecha_hora_entrada_reservada, r.fecha_hora_salida_reservada)
        FROM parqueaderos p 
        JOIN espacios e ON p.id = e.parqueadero_id 
        WHERE e.id = reservas.espacio_id
    )
WHERE metodo_pago IS NULL;

-- 7. Comentarios sobre el uso
-- Los métodos de pago se pueden activar/desactivar desde la tabla metodos_pago
-- Las transacciones se registran en transacciones_pago para auditoría
-- El campo monto_total en reservas almacena el total calculado
-- Los estados de pago permiten seguimiento completo del proceso
