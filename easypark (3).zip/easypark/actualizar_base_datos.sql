-- Script para actualizar la base de datos EasyPark con filtros de vehículo y tarifa
-- Ejecutar este script en phpMyAdmin o MySQL Workbench

-- 1. Agregar campos a la tabla parqueaderos para tipos de vehículo y categorías de tarifa
ALTER TABLE parqueaderos 
ADD COLUMN tipos_vehiculo_permitidos VARCHAR(255) DEFAULT 'carro,moto,bicicleta' COMMENT 'Tipos de vehículos permitidos separados por comas',
ADD COLUMN categoria_tarifa ENUM('economica', 'media', 'premium') DEFAULT 'media' COMMENT 'Categoría de tarifa del parqueadero',
ADD COLUMN coordenadas_lat DECIMAL(10, 8) NULL COMMENT 'Latitud del parqueadero',
ADD COLUMN coordenadas_lng DECIMAL(11, 8) NULL COMMENT 'Longitud del parqueadero',
ADD COLUMN ciudad VARCHAR(100) DEFAULT 'Medellín' COMMENT 'Ciudad donde está ubicado el parqueadero';

-- 2. Agregar campos a la tabla espacios para tipos de vehículo específicos
ALTER TABLE espacios 
ADD COLUMN tipo_vehiculo_permitido ENUM('carro', 'moto', 'bicicleta', 'todos') DEFAULT 'todos' COMMENT 'Tipo específico de vehículo para este espacio';

-- 3. Agregar campos a la tabla reservas para el tipo de vehículo
ALTER TABLE reservas 
ADD COLUMN tipo_vehiculo ENUM('carro', 'moto', 'bicicleta') DEFAULT 'carro' COMMENT 'Tipo de vehículo de la reserva';

-- 4. Crear tabla para configuración de la aplicación
CREATE TABLE IF NOT EXISTS configuracion_app (
    id INT AUTO_INCREMENT PRIMARY KEY,
    clave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NOT NULL,
    descripcion TEXT,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- 5. Insertar configuraciones por defecto
INSERT INTO configuracion_app (clave, valor, descripcion) VALUES 
('ciudad_principal', 'Medellín', 'Ciudad principal donde opera la aplicación'),
('coordenadas_ciudad_lat', '6.2442', 'Latitud del centro de la ciudad principal'),
('coordenadas_ciudad_lng', '-75.5812', 'Longitud del centro de la ciudad principal'),
('zoom_mapa_default', '12', 'Zoom por defecto del mapa'),
('google_client_id', '', 'ID del cliente de Google para login social'),
('google_client_secret', '', 'Secreto del cliente de Google para login social');

-- 6. Crear tabla para usuarios de Google (si no existe)
CREATE TABLE IF NOT EXISTS usuarios_google (
    id INT AUTO_INCREMENT PRIMARY KEY,
    google_id VARCHAR(100) NOT NULL UNIQUE,
    usuario_id INT NOT NULL,
    email VARCHAR(255) NOT NULL,
    nombre VARCHAR(255) NOT NULL,
    foto_url TEXT,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- 7. Actualizar parqueaderos existentes con coordenadas de Medellín (ejemplos)
-- Nota: Estas son coordenadas de ejemplo, deberás actualizarlas con las reales
UPDATE parqueaderos SET 
    coordenadas_lat = 6.2442 + (RAND() - 0.5) * 0.1,
    coordenadas_lng = -75.5812 + (RAND() - 0.5) * 0.1,
    ciudad = 'Medellín'
WHERE coordenadas_lat IS NULL;

-- 8. Crear índices para mejorar el rendimiento
CREATE INDEX idx_parqueaderos_ciudad ON parqueaderos(ciudad);
CREATE INDEX idx_parqueaderos_categoria_tarifa ON parqueaderos(categoria_tarifa);
CREATE INDEX idx_espacios_tipo_vehiculo ON espacios(tipo_vehiculo_permitido);
CREATE INDEX idx_reservas_tipo_vehiculo ON reservas(tipo_vehiculo);
CREATE INDEX idx_parqueaderos_coordenadas ON parqueaderos(coordenadas_lat, coordenadas_lng);

-- 9. Comentarios sobre el uso
-- Los tipos de vehículo permitidos se almacenan como string separado por comas
-- Las categorías de tarifa son: economica (< $3000/hora), media ($3000-$8000/hora), premium (> $8000/hora)
-- Las coordenadas permiten geolocalización precisa en el mapa
-- La tabla configuracion_app permite ajustar parámetros sin modificar código
