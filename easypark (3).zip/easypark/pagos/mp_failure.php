<?php
// pagos/mp_failure.php - Página de fallo de Mercado Pago
session_start();
include '../conexion.php';

// Verificar que el usuario esté logueado
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";
$reserva_info = null;

// Obtener parámetros de Mercado Pago
$preference_id = $_GET['preference_id'] ?? '';

if (!empty($preference_id)) {
    // Buscar la reserva
    $sql_reserva = "SELECT r.*, p.nombre_parqueadero, p.direccion, e.numero_espacio 
                    FROM reservas r 
                    JOIN espacios e ON r.espacio_id = e.id 
                    JOIN parqueaderos p ON e.parqueadero_id = p.id 
                    WHERE r.transaction_id = '$preference_id'";
    $resultado_reserva = $conn->query($sql_reserva);

    if ($resultado_reserva->num_rows > 0) {
        $reserva_info = $resultado_reserva->fetch_assoc();
        
        // Actualizar estado de pago a fallido
        $sql_update = "UPDATE reservas SET estado_pago = 'fallido' WHERE id = '{$reserva_info['id']}'";
        $conn->query($sql_update);

        // Actualizar transacción
        $sql_update_transaccion = "UPDATE transacciones_pago SET estado = 'REJECTED', fecha_actualizacion = NOW() WHERE reserva_id = '{$reserva_info['id']}'";
        $conn->query($sql_update_transaccion);
        
        // Liberar el espacio
        $sql_update_espacio = "UPDATE espacios SET estado = 'disponible' WHERE id = '{$reserva_info['espacio_id']}'";
        $conn->query($sql_update_espacio);
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Pago Fallido</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #1266d5;
            --error: #dc3545;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 500px;
            background: var(--card);
            padding: 40px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            text-align: center;
        }
        .header-row {
            display: flex;
            align-items: center;
            gap: 14px;
            justify-content: center;
            margin-bottom: 24px;
            flex-direction: column;
        }
        .header-row img {
            height: 80px;
            width: auto;
        }
        h1 {
            color: var(--error);
            font-size: 1.8em;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
        }
        .error-icon {
            font-size: 4em;
            color: var(--error);
            margin-bottom: 20px;
        }
        .status-message {
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 1.1em;
            font-weight: 600;
            background: #fff0f0;
            color: var(--error);
            border: 2px solid #f5c6cb;
        }
        .info-message {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 24px;
            background: #f0f8ff;
            color: var(--accent);
            border: 1px solid #dbeafe;
        }
        .actions {
            display: flex;
            gap: 12px;
            justify-content: center;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-primary {
            background: var(--accent);
            color: white;
        }
        .btn-primary:hover {
            background: #0b5ed7;
            transform: translateY(-1px);
        }
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-1px);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-row">
            <img src="../img/logo2.png" alt="EasyPark" />
            <h1>Pago Fallido</h1>
        </div>

        <div class="error-icon">❌</div>

        <div class="status-message">
            No se pudo procesar tu pago con Mercado Pago
        </div>

        <div class="info-message">
            <strong>¿Qué puedes hacer?</strong><br>
            • Verificar que tu tarjeta tenga fondos suficientes<br>
            • Intentar con otra tarjeta<br>
            • Contactar a tu banco<br>
            • Elegir pago en efectivo al llegar
        </div>

        <div class="actions">
            <a href="../Cliente/reservar.php" class="btn btn-primary">Intentar Nuevamente</a>
            <a href="../Cliente/mis_reservas.php" class="btn btn-secondary">Ver Mis Reservas</a>
        </div>
    </div>
</body>
</html>



