<?php
// pagos/payu_response.php - Página de respuesta de PayU
session_start();
include '../conexion.php';
include '../includes/PayUProcessor.php';

// Verificar que el usuario esté logueado
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: ../index.php");
    exit();
}

$mensaje = "";
$reserva_info = null;

// Obtener parámetros de PayU
$transaction_id = $_GET['transactionId'] ?? '';
$reference_code = $_GET['referenceCode'] ?? '';
$state_pol = $_GET['state_pol'] ?? '';

if (empty($transaction_id) || empty($reference_code)) {
    header("Location: ../Cliente/reservar.php?error=invalid_payment_response");
    exit();
}

// Buscar la reserva
$sql_reserva = "SELECT r.*, p.nombre_parqueadero, p.direccion, e.numero_espacio 
                FROM reservas r 
                JOIN espacios e ON r.espacio_id = e.id 
                JOIN parqueaderos p ON e.parqueadero_id = p.id 
                WHERE r.referencia_pago = '$reference_code' AND r.transaction_id = '$transaction_id'";
$resultado_reserva = $conn->query($sql_reserva);

if ($resultado_reserva->num_rows === 0) {
    header("Location: ../Cliente/reservar.php?error=reserva_no_encontrada");
    exit();
}

$reserva_info = $resultado_reserva->fetch_assoc();

// Determinar estado del pago
$estado_pago = 'fallido';
$mensaje_estado = '';

switch ($state_pol) {
    case '4': // Aprobado
        $estado_pago = 'pagado';
        $mensaje_estado = '✅ Pago aprobado exitosamente';
        break;
    case '6': // Declinado
        $estado_pago = 'fallido';
        $mensaje_estado = '❌ Pago declinado';
        break;
    case '7': // Pendiente
        $estado_pago = 'pendiente';
        $mensaje_estado = '⏳ Pago pendiente de confirmación';
        break;
    default:
        $estado_pago = 'fallido';
        $mensaje_estado = '❌ Error en el procesamiento del pago';
}

// Actualizar estado en la base de datos
$sql_update = "UPDATE reservas SET estado_pago = '$estado_pago', fecha_pago = NOW() WHERE id = '{$reserva_info['id']}'";
$conn->query($sql_update);

// Actualizar transacción
$sql_update_transaccion = "UPDATE transacciones_pago SET estado = '$estado_pago', fecha_actualizacion = NOW() WHERE reserva_id = '{$reserva_info['id']}'";
$conn->query($sql_update_transaccion);

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Confirmación de Pago</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #1266d5;
            --success: #24b358;
            --error: #dc3545;
            --warning: #ffc107;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            max-width: 500px;
            background: var(--card);
            padding: 40px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            text-align: center;
        }
        .header-row {
            display: flex;
            align-items: center;
            gap: 14px;
            justify-content: center;
            margin-bottom: 24px;
            flex-direction: column;
        }
        .header-row img {
            height: 80px;
            width: auto;
        }
        h1 {
            color: var(--accent);
            font-size: 1.8em;
            font-weight: 700;
            margin: 0;
            letter-spacing: 0.5px;
        }
        .status-message {
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 1.1em;
            font-weight: 600;
        }
        .status-success {
            background: #e8f5e8;
            color: var(--success);
            border: 2px solid #c3e6cb;
        }
        .status-error {
            background: #fff0f0;
            color: var(--error);
            border: 2px solid #f5c6cb;
        }
        .status-warning {
            background: #fffbf0;
            color: #b45309;
            border: 2px solid #fde68a;
        }
        .reserva-details {
            background: #f8fafc;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 24px;
            text-align: left;
        }
        .reserva-details h3 {
            margin-top: 0;
            color: var(--accent);
            font-size: 1.2em;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding: 4px 0;
        }
        .detail-label {
            font-weight: 600;
            color: #374151;
        }
        .detail-value {
            color: #6b7280;
        }
        .actions {
            display: flex;
            gap: 12px;
            justify-content: center;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-primary {
            background: var(--accent);
            color: white;
        }
        .btn-primary:hover {
            background: #0b5ed7;
            transform: translateY(-1px);
        }
        .btn-secondary {
            background: #6b7280;
            color: white;
        }
        .btn-secondary:hover {
            background: #4b5563;
            transform: translateY(-1px);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-row">
            <img src="../img/logo2.png" alt="EasyPark" />
            <h1>Confirmación de Pago</h1>
        </div>

        <div class="status-message <?php echo $estado_pago === 'pagado' ? 'status-success' : ($estado_pago === 'pendiente' ? 'status-warning' : 'status-error'); ?>">
            <?php echo $mensaje_estado; ?>
        </div>

        <?php if ($reserva_info): ?>
        <div class="reserva-details">
            <h3>Detalles de la Reserva</h3>
            <div class="detail-row">
                <span class="detail-label">Parqueadero:</span>
                <span class="detail-value"><?php echo htmlspecialchars($reserva_info['nombre_parqueadero']); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Dirección:</span>
                <span class="detail-value"><?php echo htmlspecialchars($reserva_info['direccion']); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Espacio:</span>
                <span class="detail-value">Puesto N° <?php echo htmlspecialchars($reserva_info['numero_espacio']); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Placa:</span>
                <span class="detail-value"><?php echo htmlspecialchars($reserva_info['placa_vehiculo']); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Entrada:</span>
                <span class="detail-value"><?php echo date('d/m/Y H:i', strtotime($reserva_info['fecha_hora_entrada_reservada'])); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Salida:</span>
                <span class="detail-value"><?php echo date('d/m/Y H:i', strtotime($reserva_info['fecha_hora_salida_reservada'])); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Total:</span>
                <span class="detail-value">$<?php echo number_format($reserva_info['monto_total'], 0, ',', '.'); ?></span>
            </div>
        </div>
        <?php endif; ?>

        <div class="actions">
            <a href="../Cliente/mis_reservas.php" class="btn btn-primary">Ver Mis Reservas</a>
            <a href="../Cliente/reservar.php" class="btn btn-secondary">Nueva Reserva</a>
        </div>
    </div>
</body>
</html>

