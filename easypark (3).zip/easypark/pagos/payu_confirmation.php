<?php
// pagos/payu_confirmation.php - Webhook de confirmación de PayU
include '../conexion.php';
include '../includes/PayUProcessor.php';

// Log de confirmaciones para debugging
$log_file = '../logs/payu_confirmations.log';
if (!file_exists('../logs')) {
    mkdir('../logs', 0777, true);
}

function logConfirmation($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] $message\n", FILE_APPEND);
}

// Obtener datos POST de PayU
$raw_data = file_get_contents('php://input');
$data = json_decode($raw_data, true);

logConfirmation("Confirmation received: " . $raw_data);

if (!$data) {
    logConfirmation("Error: Invalid JSON data");
    http_response_code(400);
    exit('Invalid data');
}

// Verificar que tenemos los datos necesarios
$transaction_id = $data['transaction']['id'] ?? '';
$reference_code = $data['transaction']['referenceCode'] ?? '';
$state = $data['transaction']['state'] ?? '';

if (empty($transaction_id) || empty($reference_code)) {
    logConfirmation("Error: Missing transaction_id or reference_code");
    http_response_code(400);
    exit('Missing required fields');
}

// Buscar la reserva
$sql_reserva = "SELECT * FROM reservas WHERE referencia_pago = '$reference_code' AND transaction_id = '$transaction_id'";
$resultado_reserva = $conn->query($sql_reserva);

if ($resultado_reserva->num_rows === 0) {
    logConfirmation("Error: Reservation not found for reference: $reference_code");
    http_response_code(404);
    exit('Reservation not found');
}

$reserva = $resultado_reserva->fetch_assoc();

// Mapear estados de PayU
$estado_pago = 'pendiente';
switch ($state) {
    case 'APPROVED':
        $estado_pago = 'pagado';
        break;
    case 'DECLINED':
    case 'EXPIRED':
        $estado_pago = 'fallido';
        break;
    case 'PENDING':
        $estado_pago = 'pendiente';
        break;
    default:
        $estado_pago = 'fallido';
}

// Actualizar estado de la reserva
$sql_update_reserva = "UPDATE reservas SET estado_pago = '$estado_pago', fecha_pago = NOW() WHERE id = '{$reserva['id']}'";
if ($conn->query($sql_update_reserva)) {
    logConfirmation("Reservation {$reserva['id']} updated to state: $estado_pago");
} else {
    logConfirmation("Error updating reservation: " . $conn->error);
}

// Actualizar transacción
$sql_update_transaccion = "UPDATE transacciones_pago SET estado = '$estado_pago', fecha_actualizacion = NOW(), respuesta_payu = '" . addslashes($raw_data) . "' WHERE reserva_id = '{$reserva['id']}'";
$conn->query($sql_update_transaccion);

// Si el pago fue aprobado, asegurar que el espacio esté ocupado
if ($estado_pago === 'pagado') {
    $sql_update_espacio = "UPDATE espacios SET estado = 'ocupado' WHERE id = '{$reserva['espacio_id']}'";
    $conn->query($sql_update_espacio);
    logConfirmation("Space {$reserva['espacio_id']} marked as occupied");
}

$conn->close();

// Responder a PayU
http_response_code(200);
echo 'OK';
logConfirmation("Confirmation processed successfully for transaction: $transaction_id");
?>
