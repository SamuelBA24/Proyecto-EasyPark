<?php
// pagos/mp_webhook.php - Webhook de Mercado Pago
include '../conexion.php';
include '../includes/MercadoPagoProcessor.php';

// Log de webhooks para debugging
$log_file = '../logs/mp_webhooks.log';
if (!file_exists('../logs')) {
    mkdir('../logs', 0777, true);
}

function logWebhook($message) {
    global $log_file;
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] $message\n", FILE_APPEND);
}

// Obtener datos POST de Mercado Pago
$raw_data = file_get_contents('php://input');
$data = json_decode($raw_data, true);

logWebhook("Webhook received: " . $raw_data);

if (!$data) {
    logWebhook("Error: Invalid JSON data");
    http_response_code(400);
    exit('Invalid data');
}

// Verificar que tenemos el ID del pago
$payment_id = $data['data']['id'] ?? '';

if (empty($payment_id)) {
    logWebhook("Error: Missing payment ID");
    http_response_code(400);
    exit('Missing payment ID');
}

// Obtener información del pago desde Mercado Pago
$mp = new MercadoPagoProcessor();
$payment_info = $mp->getPayment($payment_id);

if (!$payment_info || isset($payment_info['error'])) {
    logWebhook("Error getting payment info: " . json_encode($payment_info));
    http_response_code(400);
    exit('Error getting payment info');
}

// Buscar la reserva por external_reference
$external_reference = $payment_info['external_reference'] ?? '';
if (empty($external_reference)) {
    logWebhook("Error: Missing external_reference");
    http_response_code(400);
    exit('Missing external_reference');
}

$sql_reserva = "SELECT * FROM reservas WHERE referencia_pago = '$external_reference'";
$resultado_reserva = $conn->query($sql_reserva);

if ($resultado_reserva->num_rows === 0) {
    logWebhook("Error: Reservation not found for reference: $external_reference");
    http_response_code(404);
    exit('Reservation not found');
}

$reserva = $resultado_reserva->fetch_assoc();

// Mapear estados de Mercado Pago
$estado_pago = 'pendiente';
$estado_transaccion = 'PENDING';

switch ($payment_info['status']) {
    case 'approved':
        $estado_pago = 'pagado';
        $estado_transaccion = 'APPROVED';
        break;
    case 'rejected':
    case 'cancelled':
        $estado_pago = 'fallido';
        $estado_transaccion = 'REJECTED';
        break;
    case 'pending':
    case 'in_process':
        $estado_pago = 'pendiente';
        $estado_transaccion = 'PENDING';
        break;
    default:
        $estado_pago = 'fallido';
        $estado_transaccion = 'REJECTED';
}

// Actualizar estado de la reserva
$sql_update_reserva = "UPDATE reservas SET estado_pago = '$estado_pago', fecha_pago = NOW() WHERE id = '{$reserva['id']}'";
if ($conn->query($sql_update_reserva)) {
    logWebhook("Reservation {$reserva['id']} updated to state: $estado_pago");
} else {
    logWebhook("Error updating reservation: " . $conn->error);
}

// Actualizar transacción
$sql_update_transaccion = "UPDATE transacciones_pago SET estado = '$estado_transaccion', payment_id = '$payment_id', fecha_actualizacion = NOW(), respuesta_payu = '" . addslashes(json_encode($payment_info)) . "' WHERE reserva_id = '{$reserva['id']}'";
$conn->query($sql_update_transaccion);

// Si el pago fue aprobado, asegurar que el espacio esté ocupado
if ($estado_pago === 'pagado') {
    $sql_update_espacio = "UPDATE espacios SET estado = 'ocupado' WHERE id = '{$reserva['espacio_id']}'";
    $conn->query($sql_update_espacio);
    logWebhook("Space {$reserva['espacio_id']} marked as occupied");
} elseif ($estado_pago === 'fallido') {
    // Si el pago falló, liberar el espacio
    $sql_update_espacio = "UPDATE espacios SET estado = 'disponible' WHERE id = '{$reserva['espacio_id']}'";
    $conn->query($sql_update_espacio);
    logWebhook("Space {$reserva['espacio_id']} marked as available due to failed payment");
}

$conn->close();

// Responder a Mercado Pago
http_response_code(200);
echo 'OK';
logWebhook("Webhook processed successfully for payment: $payment_id");
?>
