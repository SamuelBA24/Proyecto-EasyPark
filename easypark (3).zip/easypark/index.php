<?php
session_start();
include 'conexion.php'; // Incluimos la conexión.

$mensaje = "";

// 1. Obtener mensaje de la URL si viene del registro exitoso
if (isset($_GET['msg'])) {
    $mensaje = htmlspecialchars($_GET['msg']);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Sanitizar y obtener datos
    $email = $conn->real_escape_string($_POST['email']);
    $contrasena = $_POST['contrasena'];
    
    // 2. Consulta para verificar el usuario
    $sql = "SELECT id, nombre, contrasena, rol FROM usuarios WHERE email = '$email'";
    $resultado = $conn->query($sql);

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        
        // 3. Verificación de Contraseña (AQUÍ DEBERÍA IR password_verify en producción)
        if ($contrasena == $usuario['contrasena']) { 
            
            // 4. Inicio de sesión exitoso: Crear variables de sesión
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre'] = $usuario['nombre'];
            $_SESSION['rol'] = $usuario['rol'];
            
            // 5. Redirigir según el rol
            if ($usuario['rol'] == 'admin') {
                header("Location: admin/dashboard.php");
            } else {
                header("Location: cliente/reservar.php");
            }
            $conn->close(); // Cerrar conexión antes de salir
            exit();
            
        } else {
            $mensaje = "Contraseña incorrecta.";
        }
    } else {
        $mensaje = "Usuario no encontrado con ese email.";
    }
    
    $conn->close(); // Cerrar la conexión si el login falla
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Login</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #1266d5;
            --accent-2: #0b5ed7;
            --muted: #6b7280;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        html,body{height:100%}
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
    /* logo for login page */
    .page-logo{display:flex;flex-direction:column;align-items:center;gap:12px;margin-bottom:24px}
    .page-logo img{height:80px;width:auto}
    .page-logo .brand{font-weight:700;color:var(--accent);font-size:1.05em;text-align:center}
        .login-container {
            background: var(--card);
            padding: 38px 32px 28px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 340px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h2 {
            text-align: center;
            color: var(--accent);
            font-size: 1.5em;
            font-weight: 700;
            margin-bottom: 18px;
            letter-spacing: 0.5px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: #1a2330;
            text-align: left;
        }
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 12px 14px;
            margin-bottom: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-sizing: border-box;
            font-size: 1em;
            background: #f8fafc;
            color: #1a2330;
            transition: border-color 0.2s;
        }
        input[type="email"]:focus, input[type="password"]:focus {
            border-color: var(--accent);
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px 0;
            background: linear-gradient(90deg,var(--accent),var(--accent-2));
            color: #f4f4f4;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1em;
            letter-spacing: 0.5px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            margin-top: 4px;
            transition: background 0.2s, transform 0.15s;
        }
        button:hover {
            background: linear-gradient(90deg,#0b5ed7,#1266d5);
            transform: translateY(-2px) scale(1.02);
        }
        .mensaje-error {
            color: #e53e3e;
            background: #fff0f0;
            border-radius: 8px;
            padding: 8px 0;
            text-align: center;
            margin-bottom: 15px;
            font-size: 0.98em;
        }
        .mensaje-info {
            color: #2e7d32;
            background: #f0fff4;
            border-radius: 8px;
            padding: 8px 0;
            text-align: center;
            margin-bottom: 15px;
            font-size: 0.98em;
        }
        .links-container {
            text-align: center;
            margin-top: 18px;
            font-size: 0.98em;
        }
        .links-container a {
            color: var(--accent);
            text-decoration: none;
            margin: 0 5px;
            padding: 2px 6px;
            border-radius: 6px;
            transition: background 0.18s;
        }
        .links-container a:hover {
            background: #f0f8ff;
            text-decoration: underline;
        }

        /* Estilos para Google Login */
        .separador {
            display: flex;
            align-items: center;
            margin: 20px 0;
            width: 100%;
        }
        .separador::before,
        .separador::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #e2e8f0;
        }
        .separador span {
            padding: 0 16px;
            color: var(--muted);
            font-size: 0.9em;
            font-weight: 500;
        }

        .btn-google {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            width: 100%;
            padding: 12px 16px;
            background: white;
            border: 1px solid #dadce0;
            border-radius: 12px;
            color: #3c4043;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95em;
            transition: all 0.2s;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .btn-google:hover {
            background: #f8f9fa;
            border-color: #bdc1c6;
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            text-decoration: none;
            color: #3c4043;
        }
        .btn-google svg {
            flex-shrink: 0;
        }
        @media (max-width:900px){
            .login-container{max-width:98vw;padding:18px 2vw;}
        }
        @media (max-width:480px){
            .login-container{padding:12px 2vw;max-width:99vw;}
            h2{font-size:1em;}
            label{font-size:0.98em;}
            button{font-size:0.98em;}
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="page-logo">
            <img src="img/logo2.png" alt="EasyPark Logo" />
            <div class="brand">Ingreso al Sistema</div>
        </div>
        
        <?php if ($mensaje): 
            // Determina si es un mensaje de éxito (info) o error.
            $clase_mensaje = (strpos($mensaje, 'exitoso') !== false || strpos($_SERVER["REQUEST_METHOD"], 'GET') !== false) ? 'mensaje-info' : 'mensaje-error';
        ?>
            <p class="<?php echo $clase_mensaje; ?>"><?php echo $mensaje; ?></p>
        <?php endif; ?>
        
        <form action="index.php" method="POST">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" required>

            <button type="submit">Iniciar Sesión</button>
        </form>

        <!-- Separador -->
        <div class="separador">
            <span>o</span>
        </div>

        <!-- Botón de Google -->
        <a href="auth/google_login.php" class="btn-google">
            <svg width="20" height="20" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Continuar con Google
        </a>
        
        <div class="links-container">
            <p>
                ¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a>
                |
                <a href="bienvenida.html">Página Principal</a> </p>
        </div>
    </div>
</body>
</html>