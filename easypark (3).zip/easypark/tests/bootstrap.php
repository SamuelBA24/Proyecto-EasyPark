<?php
// Tests removed by developer request. Bootstrap intentionally left minimal.
// If you need to re-enable tests, restore vendor/autoload.php and test bootstrap logic.
if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}
