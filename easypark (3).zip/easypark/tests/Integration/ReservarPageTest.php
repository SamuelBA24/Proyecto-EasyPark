<?php
// Integration tests removed by request. This file is intentionally left blank.

