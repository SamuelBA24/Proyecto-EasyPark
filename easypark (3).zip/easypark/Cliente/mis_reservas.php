<?php
session_start();
// Verifica que el usuario esté logueado y sea cliente
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: ../index.php"); 
    exit();
}
include '../conexion.php'; 

$usuario_id = $_SESSION['usuario_id'];

// Consulta para obtener todas las reservas del usuario, uniendo datos del espacio y parqueadero
$sql_reservas = "SELECT 
    r.id AS reserva_id, 
    r.placa_vehiculo, 
    r.fecha_hora_entrada_reservada, 
    r.fecha_hora_salida_reservada, 
    r.estado_reserva, 
    e.numero_espacio,
    p.nombre_parqueadero,
    p.direccion
FROM reservas r
JOIN espacios e ON r.espacio_id = e.id
JOIN parqueaderos p ON e.parqueadero_id = p.id
WHERE r.usuario_id = '$usuario_id'
ORDER BY r.fecha_hora_entrada_reservada DESC";

$resultado_reservas = $conn->query($sql_reservas);

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Mis Reservas</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; background-color: #f4f7fc; color: #34495e; }
        .top-logos{display:flex;align-items:center;justify-content:center;gap:20px;margin-bottom:10px}
        .top-logos img{height:68px;width:auto}
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 25px; border-radius: 8px; box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); }
        h1 { color: #007bff; border-bottom: 3px solid #eee; padding-bottom: 10px; }
        .menu-cliente a { margin-right: 15px; color: #28a745; text-decoration: none; font-weight: 600; }
        .menu-cliente a:hover { text-decoration: underline; }
        
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; font-size: 0.95em; }
        th { background-color: #007bff; color: white; text-align: center; }
        
        /* Estilos de estado de reserva */
        .confirmada { background-color: #d4edda; color: #155724; } /* Verde para confirmada/activa */
        .cancelada { background-color: #f8d7da; color: #721c24; } /* Rojo para cancelada */
        .finalizada { background-color: #f0f0f0; color: #6c757d; } /* Gris para finalizada */
        .pendiente { background-color: #fff3cd; color: #856404; } /* Amarillo para pendiente */

        .mensaje-vacio { text-align: center; padding: 30px; border: 1px solid #ccc; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="top-logos">
        <img src="../img/logo2.png" alt="EasyPark" />
    </div>
    <div class="container">
        <h1>Mis Reservas Creadas</h1>
        <p class="menu-cliente">
            <a href="reservar.php">Reservar Nuevo Espacio</a> | 
            <a href="../logout.php">Cerrar Sesión</a>
        </p>

        

        <?php if ($resultado_reservas->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Parqueadero</th>
                        <th>Espacio</th>
                        <th>Placa</th>
                        <th>Entrada Reservada</th>
                        <th>Salida Reservada</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($reserva = $resultado_reservas->fetch_assoc()): ?>
                        <tr class="<?php echo htmlspecialchars($reserva['estado_reserva']); ?>">
                            <td>
                                <strong><?php echo htmlspecialchars($reserva['nombre_parqueadero']); ?></strong><br>
                                <small><?php echo htmlspecialchars($reserva['direccion']); ?></small>
                            </td>
                            <td align="center"><strong><?php echo htmlspecialchars($reserva['numero_espacio']); ?></strong></td>
                            <td align="center"><?php echo htmlspecialchars($reserva['placa_vehiculo']); ?></td>
                            <td><?php echo date("d/m/Y H:i", strtotime($reserva['fecha_hora_entrada_reservada'])); ?></td>
                            <td><?php echo date("d/m/Y H:i", strtotime($reserva['fecha_hora_salida_reservada'])); ?></td>
                            <td align="center">
                                <strong><?php echo strtoupper(htmlspecialchars($reserva['estado_reserva'])); ?></strong>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="mensaje-vacio">
                <p>Aún no tienes ninguna reserva registrada. ¡Es hora de <a href="reservar.php">reservar tu primer puesto</a>! 🚗</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>