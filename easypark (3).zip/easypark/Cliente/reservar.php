<?php
session_start();
// Verifica que el usuario esté logueado y sea cliente
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'cliente') {
    header("Location: ../index.php"); 
    exit();
}
include '../conexion.php'; 

$usuario_id = $_SESSION['usuario_id'];
$mensaje = "";
$parqueaderos = [];
$espacios_disponibles = [];
$parqueadero_seleccionado = null;
$metodos_pago = [];

// Variables para filtros
$filtro_tipo_vehiculo = isset($_POST['filtro_tipo_vehiculo']) ? $_POST['filtro_tipo_vehiculo'] : '';
$filtro_categoria_tarifa = isset($_POST['filtro_categoria_tarifa']) ? $_POST['filtro_categoria_tarifa'] : '';
$filtro_distancia = isset($_POST['filtro_distancia']) ? $_POST['filtro_distancia'] : '10';

// Obtener métodos de pago disponibles
$sql_metodos = "SELECT codigo, nombre, descripcion, logo_url FROM metodos_pago WHERE activo = TRUE ORDER BY orden ASC";
$resultado_metodos = $conn->query($sql_metodos);
while($metodo = $resultado_metodos->fetch_assoc()) {
    $metodos_pago[] = $metodo;
}

// =========================================================
// 1. PROCESAR RESERVA FINAL (Paso 2)
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'crear_reserva') {
    
    $espacio_id = $conn->real_escape_string($_POST['espacio_id']);
    $placa = $conn->real_escape_string($_POST['placa_vehiculo']);
    $entrada = $conn->real_escape_string($_POST['fecha_hora_entrada']);
    $salida = $conn->real_escape_string($_POST['fecha_hora_salida']);
    $tipo_vehiculo = $conn->real_escape_string($_POST['tipo_vehiculo']);
    $metodo_pago = $conn->real_escape_string($_POST['metodo_pago']);

    // Validación básica
    $tiempo_actual = date('Y-m-d H:i:s');
    if ($entrada <= $tiempo_actual || $salida <= $entrada) {
        $mensaje = "❌ Error: Las fechas y horas de reserva deben ser futuras y la salida posterior a la entrada.";
    } else {
        // Inicia transacción
        $conn->begin_transaction();
        $exito = true;

        // Calcular monto total basado en horas y tarifa
        $sql_tarifa = "SELECT p.tarifa_hora FROM parqueaderos p 
                       JOIN espacios e ON p.id = e.parqueadero_id 
                       WHERE e.id = '$espacio_id'";
        $resultado_tarifa = $conn->query($sql_tarifa);
        $tarifa_hora = $resultado_tarifa->fetch_assoc()['tarifa_hora'];
        
        $horas = (strtotime($salida) - strtotime($entrada)) / 3600;
        $monto_total = $tarifa_hora * $horas;
        
        // Determinar estado de pago según método
        $estado_pago = ($metodo_pago === 'efectivo') ? 'pagado' : 'pendiente';
        
        // 1. Insertar la reserva
        $sql_insert = "INSERT INTO reservas (usuario_id, espacio_id, placa_vehiculo, fecha_hora_entrada_reservada, fecha_hora_salida_reservada, estado_reserva, tipo_vehiculo, metodo_pago, estado_pago, monto_total) 
                       VALUES ('$usuario_id', '$espacio_id', '$placa', '$entrada', '$salida', 'confirmada', '$tipo_vehiculo', '$metodo_pago', '$estado_pago', '$monto_total')";
        
        if (!$conn->query($sql_insert)) {
            $exito = false;
            $mensaje = "❌ Error al crear la reserva: " . $conn->error;
        }

        // 2. Marcar el espacio como 'ocupado'
        if ($exito) {
            $sql_update_espacio = "UPDATE espacios SET estado = 'ocupado' WHERE id = '$espacio_id' AND estado = 'disponible'";
            if (!$conn->query($sql_update_espacio)) {
                $exito = false;
                $mensaje = "❌ Error al actualizar el estado del espacio: " . $conn->error;
            }
        }

        if ($exito) {
            $reserva_id = $conn->insert_id;
            
            // Si es pago con Mercado Pago, procesar el pago
            if ($metodo_pago === 'mercadopago') {
                include '../includes/MercadoPagoProcessor.php';
                
                // Obtener datos del usuario y parqueadero
                $sql_datos = "SELECT u.nombre, u.email, p.nombre_parqueadero, p.direccion, e.numero_espacio 
                              FROM usuarios u, parqueaderos p, espacios e 
                              WHERE u.id = '$usuario_id' AND e.id = '$espacio_id' AND p.id = e.parqueadero_id";
                $resultado_datos = $conn->query($sql_datos);
                $datos = $resultado_datos->fetch_assoc();
                
                // Generar referencia única
                $referencia_pago = 'MP' . time() . $reserva_id;
                
                // Preparar datos para Mercado Pago
                $mp_data = [
                    'reserva_id' => $reserva_id,
                    'reference_code' => $referencia_pago,
                    'total_amount' => $monto_total,
                    'usuario_id' => $usuario_id,
                    'usuario_nombre' => $datos['nombre'],
                    'usuario_email' => $datos['email'],
                    'parqueadero_nombre' => $datos['nombre_parqueadero'],
                    'numero_espacio' => $datos['numero_espacio'],
                    'placa_vehiculo' => $placa
                ];
                
                // Crear preferencia en Mercado Pago
                $mp = new MercadoPagoProcessor();
                $mp_response = $mp->createPreference($mp_data);

                // Asegurar carpeta de logs
                if (!file_exists(__DIR__ . '/../logs')) {
                    @mkdir(__DIR__ . '/../logs', 0777, true);
                }
                @file_put_contents(__DIR__ . '/../logs/mp_debug.log', date('Y-m-d H:i:s') . " - createPreference response: " . json_encode($mp_response) . "\n", FILE_APPEND);

                if (isset($mp_response['id'])) {
                    $preference_id = $mp_response['id'];
                    
                    // Primero confirmar la reserva
                    $conn->commit();
                    
                    // Iniciar nueva transacción para el registro de pago
                    $conn->begin_transaction();
                    
                    try {
                        // Actualizar reserva con datos de Mercado Pago
                        $sql_update_mp = "UPDATE reservas SET referencia_pago = '$referencia_pago', transaction_id = '$preference_id' WHERE id = '$reserva_id'";
                        $conn->query($sql_update_mp);
                        
                        // Registrar transacción
                        $sql_transaccion = "INSERT INTO transacciones_pago (reserva_id, metodo_pago, referencia_pago, preference_id, monto, estado, respuesta_payu) 
                                           VALUES ('$reserva_id', 'mercadopago', '$referencia_pago', '$preference_id', '$monto_total', 'PENDING', '" . json_encode($mp_response) . "')";
                        $conn->query($sql_transaccion);
                        
                        // Confirmar la transacción de pago
                        $conn->commit();
                    } catch (Exception $e) {
                        $conn->rollback();
                        error_log("Error al registrar transacción MP: " . $e->getMessage());
                        // Continuamos ya que la reserva está creada
                    }
                    
                    $conn->commit();
                    
                    // Redirigir a Mercado Pago
                    $payment_url = $mp->getPaymentUrl($preference_id);
                    header("Location: $payment_url");
                    exit();
                } else {
                    $conn->rollback();
                    $mensaje = "❌ Error al procesar el pago con Mercado Pago: " . (isset($mp_response['error']) ? $mp_response['error'] : 'Error desconocido');
                }
            } else {
                // Pago en efectivo - confirmar directamente
                $conn->commit();
                header("Location: mis_reservas.php?msg=" . urlencode("✅ Reserva creada con éxito para la placa $placa. Pago en efectivo al llegar."));
                $conn->close();
                exit();
            }
        } else {
            $conn->rollback();
            // El mensaje ya fue generado en los errores anteriores
        }
    }
}


// =========================================================
// 2. OBTENER ESPACIOS DISPONIBLES EN UN PARQUEADERO (Paso 1b)
// =========================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion']) && $_POST['accion'] == 'seleccionar_parqueadero') {
    
    $parqueadero_id = $conn->real_escape_string($_POST['parqueadero_id']);

    // Obtener info del parqueadero seleccionado
    $sql_park_info = "SELECT id, nombre_parqueadero, direccion, tarifa_hora, imagen FROM parqueaderos WHERE id = '$parqueadero_id'";
    $result_park_info = $conn->query($sql_park_info);
    if ($result_park_info->num_rows > 0) {
        $parqueadero_seleccionado = $result_park_info->fetch_assoc();
    }

    // Obtener los espacios disponibles en ese parqueadero
    $sql_espacios = "SELECT id, numero_espacio FROM espacios WHERE parqueadero_id = '$parqueadero_id' AND estado = 'disponible' ORDER BY numero_espacio ASC";
    $result_espacios = $conn->query($sql_espacios);
    while($fila = $result_espacios->fetch_assoc()) {
        $espacios_disponibles[] = $fila;
    }

    // Si no hay espacios disponibles, mostramos un error en la siguiente vista
    if (empty($espacios_disponibles)) {
        $mensaje = "⚠️ Lo sentimos, el parqueadero **{$parqueadero_seleccionado['nombre_parqueadero']}** no tiene espacios disponibles en este momento.";
    }

} else {
    // =========================================================
    // 3. OBTENER PARQUEADEROS CON FILTROS (Paso 1a - Vista inicial)
    // =========================================================
    
    // Construir consulta con filtros
    $where_conditions = ["ciudad = 'Medellín'", "activo = TRUE"];
    $params = [];
    
    // Filtro por tipo de vehículo
    if (!empty($filtro_tipo_vehiculo)) {
        $where_conditions[] = "tipos_vehiculo_permitidos LIKE '%$filtro_tipo_vehiculo%'";
    }
    
    // Filtro por categoría de tarifa
    if (!empty($filtro_categoria_tarifa)) {
        $where_conditions[] = "categoria_tarifa = '$filtro_categoria_tarifa'";
    }
    
    $sql_parkings = "SELECT id, nombre_parqueadero, direccion, tarifa_hora, categoria_tarifa, 
                            tipos_vehiculo_permitidos, coordenadas_lat, coordenadas_lng, imagen
                     FROM parqueaderos 
                     WHERE " . implode(' AND ', $where_conditions) . "
                     ORDER BY nombre_parqueadero ASC";
    
    $resultado_parkings = $conn->query($sql_parkings);
    while($row = $resultado_parkings->fetch_assoc()) {
        $parqueaderos[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Reservar Espacio</title>
    <link
        rel="stylesheet"
        href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
    />
    <script
        src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js">
    </script>
    <!-- Librería principal de Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <!-- Librería para mostrar rutas -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>

    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #1266d5;
            --accent-2: #0b5ed7;
            --success: #24b358;
            --success-2: #1e8f40;
            --muted: #6b7280;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        html,body{height:100%}
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 820px;
            margin: 32px auto 0 auto;
            background: var(--card);
            padding: 38px 32px 28px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }
          .header-row{display:flex;align-items:center;gap:14px;justify-content:center;margin-bottom:8px;flex-direction:column}
          .header-row img{height:84px;width:auto;display:block}
          /* Si por alguna razón existen dos imágenes en la cabecera, ocultamos la segunda
              para garantizar que solo se muestre un logo en esta página */
          .header-row img + img{display:none}
        h1 {
            color: var(--accent);
            font-size: 1.6em;
            font-weight: 700;
            text-align: center;
            margin:0;
            letter-spacing: 0.5px;
        }
        .menu-cliente {
            text-align: center;
            margin-bottom: 18px;
        }
        .menu-cliente a {
            margin: 0 10px;
            color: var(--success);
            text-decoration: none;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 8px;
            transition: background 0.18s;
        }
        .menu-cliente a:hover {
            background: #eafbe7;
            text-decoration: underline;
        }
        .alerta {
            padding: 12px 0;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: 500;
            text-align: center;
            font-size: 1em;
        }
        .error {
            background-color: #fff0f0;
            color: #dc3545;
            border: 1px solid #f5c6cb;
        }
        .exito {
            background-color: #eafbe7;
            color: #1e8f40;
            border: 1px solid #c3e6cb;
        }

        /* NUEVO CONTENEDOR CON SCROLL */
        .map-scroll-container {
            width: 100%;
            height: 400px;
            overflow: auto;
            border-radius: 10px;
            border: 2px solid #e2e8f0;
            box-shadow: 0 4px 12px rgba(16,32,64,0.08);
            margin-bottom: 24px;
        }

        #map {
            height: 600px;
            width: 800px;
            min-width: 800px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: 500;
            color: #1a2330;
            text-align: left;
        }
        input[type="text"], input[type="datetime-local"], select {
            width: 100%;
            padding: 12px 14px;
            margin-bottom: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-sizing: border-box;
            font-size: 1em;
            background: #f8fafc;
            color: #1a2330;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus, input[type="datetime-local"]:focus, select:focus {
            border-color: var(--accent);
            outline: none;
        }
        button {
            background: linear-gradient(90deg,var(--success),var(--success-2));
            color: #f4f4f4;
            padding: 12px 0;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1em;
            letter-spacing: 0.5px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            margin-top: 4px;
            margin-bottom: 5px;
            width: 100%;
            transition: background 0.2s, transform 0.15s;
        }
        button:hover {
            background: linear-gradient(90deg,var(--success-2),var(--success));
            transform: translateY(-2px) scale(1.02);
        }

        .parking-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-top: 20px;
        }
        .parking-card {
            background: #f6f8fa;
            padding: 24px 18px;
            border-radius: 14px;
            box-shadow: 0 2px 8px rgba(16,32,64,0.04);
            border-left: 6px solid var(--success);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            min-width: 220px;
            transition: box-shadow 0.18s, transform 0.18s;
        }
        .parking-card:hover {
            box-shadow: 0 8px 24px rgba(16,32,64,0.10);
            transform: translateY(-4px) scale(1.03);
        }
        .parking-card h3 {
            margin-top: 0;
            color: var(--accent);
            font-size: 1.15em;
            font-weight: 700;
        }
        .parking-card p {
            margin: 5px 0;
            font-size: 0.98em;
            color: var(--muted);
        }
        .parking-card button {
            background: linear-gradient(90deg,var(--success),var(--success-2));
            margin-top: 10px;
            color: #f4f4f4;
            border-radius: 10px;
            font-weight: 600;
            font-size: 1em;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            border: none;
            padding: 10px 0;
            width: 100%;
            transition: background 0.2s, transform 0.15s;
        }
        .parking-card button:hover {
            background: linear-gradient(90deg,var(--success-2),var(--success));
            transform: translateY(-2px) scale(1.02);
        }

        /* Estilos para filtros */
        .filtros-container {
            background: #f8fafc;
            padding: 24px;
            border-radius: 14px;
            margin-bottom: 24px;
            border: 1px solid #e2e8f0;
        }
        .filtros-container h3 {
            margin-top: 0;
            color: var(--accent);
            font-size: 1.2em;
            margin-bottom: 16px;
        }
        .filtros-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 16px;
        }
        .filtro-group {
            display: flex;
            flex-direction: column;
        }
        .filtro-group label {
            font-size: 0.9em;
            font-weight: 600;
            margin-bottom: 6px;
            color: #374151;
        }
        .filtro-group select {
            padding: 10px 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            background: white;
            font-size: 0.95em;
        }
        .filtros-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        .filtros-actions button {
            background: linear-gradient(90deg, var(--accent), var(--accent-2));
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            width: auto;
        }
        .filtros-actions button:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(18, 102, 213, 0.3);
        }
        .btn-limpiar {
            color: var(--muted);
            text-decoration: none;
            padding: 10px 16px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            background: white;
            transition: all 0.2s;
        }
        .btn-limpiar:hover {
            background: #f9fafb;
            border-color: var(--accent);
            color: var(--accent);
        }

        /* Información adicional en tarjetas */
        .parking-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 12px 0;
            padding: 8px 0;
            border-top: 1px solid #e5e7eb;
        }
        .categoria-tarifa {
            font-size: 0.85em;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 6px;
        }
        .categoria-economica {
            background: #dcfce7;
            color: #166534;
        }
        .categoria-media {
            background: #dbeafe;
            color: #1e40af;
        }
        .categoria-premium {
            background: #fef3c7;
            color: #92400e;
        }
        .tipos-vehiculo {
            display: flex;
            gap: 4px;
        }
        .tipo-vehiculo {
            font-size: 1.2em;
            padding: 2px;
        }

        /* Estilos para métodos de pago */
        .metodos-pago-container {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 16px;
        }
        .metodo-pago-option {
            position: relative;
        }
        .metodo-pago-option input[type="radio"] {
            position: absolute;
            opacity: 0;
            pointer-events: none;
        }
        .metodo-pago-label {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            background: #f8fafc;
            cursor: pointer;
            transition: all 0.2s;
        }
        .metodo-pago-label:hover {
            border-color: var(--accent);
            background: #f0f8ff;
        }
        .metodo-pago-option input[type="radio"]:checked + .metodo-pago-label {
            border-color: var(--accent);
            background: #e3f2fd;
            box-shadow: 0 0 0 3px rgba(18, 102, 213, 0.1);
        }
        .metodo-pago-logo {
            width: 40px;
            height: 25px;
            object-fit: contain;
        }
        .metodo-pago-icon {
            font-size: 1.5em;
            width: 40px;
            text-align: center;
        }
        .metodo-pago-info {
            flex: 1;
        }
        .metodo-pago-nombre {
            font-weight: 600;
            color: #1a2330;
            margin-bottom: 4px;
        }
        .metodo-pago-descripcion {
            font-size: 0.9em;
            color: var(--muted);
        }
        @media (max-width:900px){
            .container{max-width:98vw;padding:12px 2vw;}
        }
        @media (max-width:640px){
            .container{padding:8px 2vw;}
            h1{font-size:1em;}
            .parking-card{padding:8px 2vw;}
            .parking-list{grid-template-columns:1fr;gap:12px;}
            label{font-size:0.98em;}
            button{font-size:0.98em;}
            .map-scroll-container{height:300px;}
            #map{height:500px;width:600px;min-width:600px;}
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-row">
            <img src="../img/logo2.png" alt="EasyPark" />
            <h1>Reservar Espacio de Parqueo</h1>
        </div>
        <p class="menu-cliente">
            <a href="reservar.php">Reservar Ahora</a> | 
            <a href="mis_reservas.php">Ver Mis Reservas</a> | 
            <a href="../logout.php">Cerrar Sesión</a>
        </p>

        <div class="map-scroll-container">
            <div id="map"></div>
        </div>

        <?php if ($mensaje): ?>
            <div class="alerta <?php echo strpos($mensaje, '❌') !== false || strpos($mensaje, '⚠️') !== false ? 'error' : 'exito'; ?>">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>

        <?php if ($parqueadero_seleccionado): ?>
        
        <h2>Reserva en: <?php echo htmlspecialchars($parqueadero_seleccionado['nombre_parqueadero']); ?></h2>
        <p>Dirección: **<?php echo htmlspecialchars($parqueadero_seleccionado['direccion']); ?>** | Tarifa: **$<?php echo number_format($parqueadero_seleccionado['tarifa_hora'], 0, ',', '.'); ?>/hora**</p>
        
        <?php if (!empty($espacios_disponibles)): ?>

        <form action="reservar.php" method="POST">
            <input type="hidden" name="accion" value="crear_reserva">
            
            <label for="espacio_id">Seleccionar Puesto Disponible:</label>
            <select id="espacio_id" name="espacio_id" required>
                <?php foreach ($espacios_disponibles as $espacio): ?>
                    <option value="<?php echo $espacio['id']; ?>">Puesto N° <?php echo htmlspecialchars($espacio['numero_espacio']); ?></option>
                <?php endforeach; ?>
            </select>

            <label for="tipo_vehiculo">Tipo de Vehículo:</label>
            <select id="tipo_vehiculo" name="tipo_vehiculo" required>
                <option value="carro">🚗 Carro</option>
                <option value="moto">🏍️ Moto</option>
                <option value="bicicleta">🚲 Bicicleta</option>
            </select>

            <label for="placa_vehiculo">Placa del Vehículo (Ej: ABC123):</label>
            <input type="text" id="placa_vehiculo" name="placa_vehiculo" required maxlength="7">

            <label for="fecha_hora_entrada">Fecha y Hora de Entrada:</label>
            <input type="datetime-local" id="fecha_hora_entrada" name="fecha_hora_entrada" required min="<?php echo date('Y-m-d\TH:i'); ?>">

            <label for="fecha_hora_salida">Fecha y Hora de Salida (Debe ser posterior a la entrada):</label>
            <input type="datetime-local" id="fecha_hora_salida" name="fecha_hora_salida" required min="<?php echo date('Y-m-d\TH:i'); ?>">

            <label for="metodo_pago">Método de Pago:</label>
            <div class="metodos-pago-container">
                <?php foreach ($metodos_pago as $metodo): ?>
                <div class="metodo-pago-option">
                    <?php $logo = !empty($metodo['logo_url']) ? $metodo['logo_url'] : ''; ?>
                    <input data-logo="<?php echo htmlspecialchars($logo); ?>" type="radio" id="metodo_<?php echo $metodo['codigo']; ?>" name="metodo_pago" value="<?php echo $metodo['codigo']; ?>" required>
                    <label for="metodo_<?php echo $metodo['codigo']; ?>" class="metodo-pago-label">
                        <?php if (!empty($logo)): ?>
                            <img src="<?php echo $logo; ?>" alt="<?php echo $metodo['nombre']; ?>" class="metodo-pago-logo">
                        <?php else: ?>
                            <span class="metodo-pago-icon">💰</span>
                        <?php endif; ?>
                        <div class="metodo-pago-info">
                            <div class="metodo-pago-nombre"><?php echo htmlspecialchars($metodo['nombre']); ?></div>
                            <div class="metodo-pago-descripcion"><?php echo htmlspecialchars($metodo['descripcion']); ?></div>
                        </div>
                    </label>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="submit" id="confirmar-btn"><img id="checkout-logo" src="" alt="" style="height:20px;margin-right:8px;display:none;vertical-align:middle;"> <span id="confirm-text">Confirmar Reserva</span></button>
        </form>

        <?php else: ?>
             <div class="alerta error">
                No hay puestos disponibles en este momento. Por favor, selecciona otro parqueadero.
             </div>
        <?php endif; ?>

        <p style="text-align: center; margin-top: 20px;"><a href="reservar.php">← Seleccionar otro parqueadero</a></p>


        <?php else: ?>

        <h2>Paso 1: Elige tu Parqueadero</h2>
        
        <!-- Sistema de Filtros -->
        <div class="filtros-container">
            <h3>🔍 Filtros de Búsqueda</h3>
            <form method="POST" action="reservar.php" class="filtros-form">
                <div class="filtros-row">
                    <div class="filtro-group">
                        <label for="filtro_tipo_vehiculo">Tipo de Vehículo:</label>
                        <select id="filtro_tipo_vehiculo" name="filtro_tipo_vehiculo">
                            <option value="">Todos los tipos</option>
                            <option value="carro" <?php echo $filtro_tipo_vehiculo === 'carro' ? 'selected' : ''; ?>>🚗 Carro</option>
                            <option value="moto" <?php echo $filtro_tipo_vehiculo === 'moto' ? 'selected' : ''; ?>>🏍️ Moto</option>
                            <option value="bicicleta" <?php echo $filtro_tipo_vehiculo === 'bicicleta' ? 'selected' : ''; ?>>🚲 Bicicleta</option>
                        </select>
                    </div>
                    
                    <div class="filtro-group">
                        <label for="filtro_categoria_tarifa">Categoría de Tarifa:</label>
                        <select id="filtro_categoria_tarifa" name="filtro_categoria_tarifa">
                            <option value="">Todas las categorías</option>
                            <option value="economica" <?php echo $filtro_categoria_tarifa === 'economica' ? 'selected' : ''; ?>>💰 Económica (< $3,000/h)</option>
                            <option value="media" <?php echo $filtro_categoria_tarifa === 'media' ? 'selected' : ''; ?>>💳 Media ($3,000 - $8,000/h)</option>
                            <option value="premium" <?php echo $filtro_categoria_tarifa === 'premium' ? 'selected' : ''; ?>>💎 Premium (> $8,000/h)</option>
                        </select>
                    </div>
                    
                    <div class="filtro-group">
                        <label for="filtro_distancia">Distancia Máxima:</label>
                        <select id="filtro_distancia" name="filtro_distancia">
                            <option value="5" <?php echo $filtro_distancia === '5' ? 'selected' : ''; ?>>5 km</option>
                            <option value="10" <?php echo $filtro_distancia === '10' ? 'selected' : ''; ?>>10 km</option>
                            <option value="15" <?php echo $filtro_distancia === '15' ? 'selected' : ''; ?>>15 km</option>
                            <option value="20" <?php echo $filtro_distancia === '20' ? 'selected' : ''; ?>>20 km</option>
                        </select>
                    </div>
                </div>
                
                <div class="filtros-actions">
                    <button type="submit" name="aplicar_filtros">🔍 Aplicar Filtros</button>
                    <a href="reservar.php" class="btn-limpiar">🧹 Limpiar Filtros</a>
                </div>
            </form>
        </div>
        
        <?php if (!empty($parqueaderos)): ?>
            <div class="parking-list">
                <?php foreach ($parqueaderos as $p): ?>
                <div class="parking-card">
                    <h3><?php echo htmlspecialchars($p['nombre_parqueadero']); ?></h3>
                    <p>📍 <?php echo htmlspecialchars($p['direccion']); ?></p>
                    <p>💰 Tarifa: **$<?php echo number_format($p['tarifa_hora'], 0, ',', '.'); ?>/hora**</p>
                    
                    <!-- Información de categoría y tipos de vehículo -->
                    <div class="parking-info">
                        <span class="categoria-tarifa categoria-<?php echo $p['categoria_tarifa']; ?>">
                            <?php 
                            $categorias = [
                                'economica' => '💰 Económica',
                                'media' => '💳 Media', 
                                'premium' => '💎 Premium'
                            ];
                            echo $categorias[$p['categoria_tarifa']] ?? '💳 Media';
                            ?>
                        </span>
                        
                        <div class="tipos-vehiculo">
                            <?php 
                            $tipos = explode(',', $p['tipos_vehiculo_permitidos']);
                            $iconos = ['carro' => '🚗', 'moto' => '🏍️', 'bicicleta' => '🚲'];
                            foreach($tipos as $tipo): 
                                $tipo = trim($tipo);
                                if(isset($iconos[$tipo])):
                            ?>
                                <span class="tipo-vehiculo" title="<?php echo ucfirst($tipo); ?>"><?php echo $iconos[$tipo]; ?></span>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                        </div>
                    </div>
                    
                    <form action="reservar.php" method="POST">
                        <input type="hidden" name="accion" value="seleccionar_parqueadero">
                        <input type="hidden" name="parqueadero_id" value="<?php echo $p['id']; ?>">
                        <button type="submit">Reservar Aquí</button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alerta error">
                No hay parqueaderos registrados en el sistema en este momento.
            </div>
        <?php endif; ?>
        
        <?php endif; ?>
    </div>
</body>
<script>
// Variables globales del mapa
let map;
let iconoParqueadero;
let iconoUsuario;

// Crear iconos personalizados
iconoParqueadero = L.divIcon({
    className: 'custom-parking-icon',
    html: '<div style="background: #1266d5; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; font-size: 16px; font-weight: bold; border: 3px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">P</div>',
    iconSize: [30, 30],
    iconAnchor: [15, 15]
});

iconoUsuario = L.divIcon({
    className: 'custom-user-icon',
    html: '<div style="background: #24b358; color: white; border-radius: 50%; width: 25px; height: 25px; display: flex; align-items: center; justify-content: center; font-size: 14px; border: 2px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">📍</div>',
    iconSize: [25, 25],
    iconAnchor: [12, 12]
});

<?php if ($parqueadero_seleccionado): ?>
    const direccionParqueadero = "<?php echo htmlspecialchars($parqueadero_seleccionado['direccion']); ?>";
    const nombreParqueadero = "<?php echo htmlspecialchars($parqueadero_seleccionado['nombre_parqueadero']); ?>";

    // Crear mapa base centrado en Medellín
    map = L.map("map").setView([6.2442, -75.5812], 12);

    // Agregar capa base de OpenStreetMap
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors"
    }).addTo(map);

    // Buscar coordenadas de la dirección del parqueadero con Nominatim
    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(direccionParqueadero)}&countrycodes=co`)
        .then(res => res.json())
        .then(data => {
            if (data.length > 0) {
                const latParqueadero = parseFloat(data[0].lat);
                const lonParqueadero = parseFloat(data[0].lon);

                // Agregar marcador del parqueadero con icono personalizado
                const imgUrl = <?php echo json_encode(!empty($parqueadero_seleccionado['imagen']) ? ('../uploads/parqueaderos/' . $parqueadero_seleccionado['imagen']) : null); ?>;
                const popupHtml = `
                    <div style="max-width:260px">
                        <div style="font-weight:700;color:#1266d5;margin-bottom:6px">${nombreParqueadero}</div>
                        ${imgUrl ? `<img src="${imgUrl}" alt="${nombreParqueadero}" style="width:100%;height:140px;object-fit:cover;border-radius:8px;margin-bottom:8px"/>` : ''}
                        <div style="color:#374151">📍 ${direccionParqueadero}</div>
                    </div>`;
                const markerParqueadero = L.marker([latParqueadero, lonParqueadero], {icon: iconoParqueadero})
                    .addTo(map)
                    .bindPopup(popupHtml);
                markerParqueadero.on('mouseover', () => markerParqueadero.openPopup());

                // Intentar obtener ubicación del usuario
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(pos => {
                        const latUser = pos.coords.latitude;
                        const lonUser = pos.coords.longitude;

                        // Centrar el mapa entre ambos puntos
                        const bounds = L.latLngBounds([[latUser, lonUser], [latParqueadero, lonParqueadero]]);
                        map.fitBounds(bounds);

                        // Agregar marcador del usuario con icono personalizado
                        const markerUser = L.marker([latUser, lonUser], {icon: iconoUsuario})
                            .addTo(map)
                            .bindPopup("📍 Tu ubicación actual")
                            .openPopup();

                        // Mostrar la ruta entre los dos puntos
                        L.Routing.control({
                            waypoints: [
                                L.latLng(latUser, lonUser),
                                L.latLng(latParqueadero, lonParqueadero)
                            ],
                            routeWhileDragging: false,
                            lineOptions: {
                                styles: [{ color: "blue", opacity: 0.8, weight: 5 }]
                            },
                            language: "es"
                        }).addTo(map);
                    }, () => {
                        alert("No se pudo obtener tu ubicación actual.");
                        map.setView([latParqueadero, lonParqueadero], 16);
                    });
                } else {
                    alert("La geolocalización no es soportada por este navegador.");
                }
            } else {
                alert("No se pudo localizar la dirección del parqueadero en el mapa.");
            }
        })
        .catch(err => console.error("Error al buscar dirección:", err));

<?php else: ?>
    // Si no hay parqueadero seleccionado, mostrar mapa de Medellín con todos los parqueaderos
    map = L.map("map").setView([6.2442, -75.5812], 12);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors"
    }).addTo(map);

    // Obtener ubicación del usuario
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(pos => {
            const lat = pos.coords.latitude;
            const lon = pos.coords.longitude;

            // Agregar marcador del usuario
            L.marker([lat, lon], {icon: iconoUsuario})
                .addTo(map)
                .bindPopup("📍 Estás aquí")
                .openPopup();

            // Centrar mapa en la ubicación del usuario
            map.setView([lat, lon], 14);
        }, () => {
            // Si no se puede obtener la ubicación, mantener centrado en Medellín
            console.log("No se pudo obtener la ubicación del usuario");
        });
    }

    // Agregar marcadores de parqueaderos disponibles
    <?php if (!empty($parqueaderos)): ?>
        <?php foreach ($parqueaderos as $p): ?>
            <?php if (!empty($p['coordenadas_lat']) && !empty($p['coordenadas_lng'])): ?>
                (function(){
                    const nombre = <?php echo json_encode($p['nombre_parqueadero']); ?>;
                    const direccion = <?php echo json_encode($p['direccion']); ?>;
                    const tarifa = <?php echo json_encode(number_format($p['tarifa_hora'], 0, ',', '.')); ?>;
                    const imgUrl = <?php echo json_encode(!empty($p['imagen']) ? ('../uploads/parqueaderos/' . $p['imagen']) : null); ?>;
                    const popupHtml = `
                        <div style="max-width:260px">
                            <div style=\"font-weight:700;color:#1266d5;margin-bottom:6px\">${nombre}</div>
                            ${imgUrl ? `<img src=\"${imgUrl}\" alt=\"${nombre}\" style=\"width:100%;height:140px;object-fit:cover;border-radius:8px;margin-bottom:8px\"/>` : ''}
                            <div style=\"color:#374151\">📍 ${direccion}</div>
                            <div style=\"margin-top:6px;color:#0b5ed7\">💰 $${tarifa}/hora</div>
                        </div>`;
                    const m = L.marker([<?php echo $p['coordenadas_lat']; ?>, <?php echo $p['coordenadas_lng']; ?>], {icon: iconoParqueadero})
                        .addTo(map)
                        .bindPopup(popupHtml);
                    m.on('mouseover', () => m.openPopup());
                })();
            <?php endif; ?>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endif; ?>

// --- Código JS para actualizar el botón de confirmación con el logo del método seleccionado ---
document.addEventListener('DOMContentLoaded', function() {
    const radios = document.querySelectorAll('input[name="metodo_pago"]');
    const logoImg = document.getElementById('checkout-logo');
    const confirmText = document.getElementById('confirm-text');

    function updateButton() {
        const selected = document.querySelector('input[name="metodo_pago"]:checked');
        if (!selected) {
            logoImg.style.display = 'none';
            confirmText.textContent = 'Confirmar Reserva';
            return;
        }
        const logo = selected.getAttribute('data-logo');
        if (logo) {
            logoImg.src = logo;
            logoImg.style.display = 'inline-block';
            confirmText.textContent = 'Pagar con ' + (selected.nextElementSibling ? selected.nextElementSibling.querySelector('.metodo-pago-nombre')?.textContent?.trim() || '' : '');
        } else {
            logoImg.style.display = 'none';
            confirmText.textContent = 'Confirmar Reserva';
        }
    }

    radios.forEach(r => r.addEventListener('change', updateButton));
    // Ejecutar al cargar para reflejar selección por defecto
    updateButton();
});
</script>

</html>