Pruebas para EasyPark

Requisitos previos

- PHP >= 7.4
- Composer
- ngrok (opcional, para exponer localhost durante pruebas de integración y webhooks)
- k6 (para pruebas de carga)

Instalación de dependencias

1. Desde la raíz del proyecto (donde está composer.json):

```bash
composer install --dev
```

Configuración

- Para las pruebas de integración, exporta la variable de entorno TEST_BASE_URL apuntando a tu servidor (puede ser la URL de ngrok):

```powershell
# Windows PowerShell
$env:TEST_BASE_URL = 'https://charise-dualistic-brigida.ngrok-free.dev'
```

Ejecutar tests unitarios

```bash
# Ejecuta todos los tests configurados en phpunit.xml
vendor/bin/phpunit --configuration phpunit.xml
```

Ejecutar un test en particular

```bash
vendor/bin/phpunit tests/Unit/MercadoPagoProcessorTest.php
```

Generar informe de cobertura (opcional)

```bash
vendor/bin/phpunit --coverage-html build/coverage
```

Pruebas de integración

- Asegúrate de que tu servidor está accesible desde TEST_BASE_URL (ngrok activo). Luego:

```bash
vendor/bin/phpunit --testsuite "Integration Tests"
```

Pruebas removidas

Este archivo de instrucciones de pruebas fue removido del repositorio por solicitud del desarrollador.
Si necesitas volver a habilitar pruebas, crea un nuevo `README_TESTING.md` con las instrucciones actualizadas.
