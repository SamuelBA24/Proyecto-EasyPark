<?php
// Interface removed for unit testing scaffolding per developer request.
// If you need a Repository interface, please add a new, project-specific interface.

