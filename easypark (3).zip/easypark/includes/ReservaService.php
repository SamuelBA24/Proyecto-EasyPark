<?php
// ReservaService removed: this file was used only for unit testing scaffolding.
// Per developer request, its content has been removed. If required, reintroduce a
// domain-specific service implementation following project conventions.

