<?php
// Interface removed for unit testing scaffolding per developer request.

