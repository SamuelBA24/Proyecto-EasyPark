<?php
// Clase para manejar pagos con PayU Colombia
class PayUProcessor {
    private $config;
    private $credentials;
    
    public function __construct() {
        $this->config = include '../config/payu_config.php';
        $env = $this->config['payu']['environment'];
        $this->credentials = $this->config['payu'][$env];
    }
    
    /**
     * Crear transacción de pago
     */
    public function createPayment($reserva_data) {
        $transaction = [
            'order' => [
                'accountId' => $this->credentials['merchant_id'],
                'referenceCode' => $reserva_data['reference_code'],
                'description' => "Reserva de parqueo - {$reserva_data['parqueadero_nombre']}",
                'language' => $this->config['payu']['language'],
                'signature' => $this->generateSignature($reserva_data),
                'notifyUrl' => $this->config['payu']['confirmation_url'],
                'additionalValues' => [
                    'TX_VALUE' => [
                        'value' => $reserva_data['total_amount'],
                        'currency' => $this->config['payu']['currency']
                    ],
                    'TX_TAX' => [
                        'value' => '0',
                        'currency' => $this->config['payu']['currency']
                    ],
                    'TX_TAX_RETURN_BASE' => [
                        'value' => $reserva_data['total_amount'],
                        'currency' => $this->config['payu']['currency']
                    ]
                ],
                'buyer' => [
                    'merchantBuyerId' => $reserva_data['usuario_id'],
                    'fullName' => $reserva_data['usuario_nombre'],
                    'emailAddress' => $reserva_data['usuario_email'],
                    'contactPhone' => $reserva_data['usuario_telefono'] ?? '',
                    'dniNumber' => $reserva_data['usuario_documento'] ?? ''
                ],
                'shippingAddress' => [
                    'street1' => $reserva_data['parqueadero_direccion'],
                    'city' => 'Medellín',
                    'state' => 'Antioquia',
                    'country' => $this->config['payu']['country'],
                    'postalCode' => '050001'
                ]
            ],
            'expirationDate' => date('c', strtotime('+1 hour')),
            'ipAddress' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'userAgent' => $_SERVER['HTTP_USER_AGENT'] ?? 'EasyPark'
        ];
        
        return $this->sendRequest($transaction);
    }
    
    /**
     * Generar firma de seguridad
     */
    private function generateSignature($data) {
        $signature_string = $this->credentials['api_key'] . '~' . 
                           $this->credentials['merchant_id'] . '~' . 
                           $data['reference_code'] . '~' . 
                           $data['total_amount'] . '~' . 
                           $this->config['payu']['currency'];
        
        return md5($signature_string);
    }
    
    /**
     * Enviar solicitud a PayU
     */
    private function sendRequest($transaction) {
        $url = $this->credentials['base_url'];
        
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Basic ' . base64_encode($this->credentials['api_login'] . ':' . $this->credentials['api_key'])
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($transaction));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return ['error' => 'Error de conexión: ' . $error];
        }
        
        $data = json_decode($response, true);
        
        if ($http_code !== 200) {
            return ['error' => 'Error HTTP: ' . $http_code, 'response' => $data];
        }
        
        return $data;
    }
    
    /**
     * Verificar respuesta de PayU
     */
    public function verifyResponse($transaction_id, $reference_code) {
        $url = $this->credentials['base_url'] . '/reports-api/4.0/service.cgi';
        
        $query = [
            'merchantId' => $this->credentials['merchant_id'],
            'transactionId' => $transaction_id,
            'referenceCode' => $reference_code
        ];
        
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'Authorization: Basic ' . base64_encode($this->credentials['api_login'] . ':' . $this->credentials['api_key'])
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url . '?' . http_build_query($query));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            return json_decode($response, true);
        }
        
        return false;
    }
    
    /**
     * Obtener URL de pago
     */
    public function getPaymentUrl($transaction_id) {
        $base_url = $this->config['payu']['environment'] === 'sandbox' 
            ? 'https://sandbox.checkout.payulatam.com/ppp-web-gateway-payu/'
            : 'https://checkout.payulatam.com/ppp-web-gateway-payu/';
            
        return $base_url . '?transactionId=' . $transaction_id;
    }
}
