<?php
// Clase para manejar pagos con Mercado Pago Colombia
class MercadoPagoProcessor {
    private $config;
    private $credentials;
    
    public function __construct() {
        $this->config = include '../config/mercadopago_config.php';
        $env = $this->config['mercadopago']['environment'];
        $this->credentials = $this->config['mercadopago'][$env];
    }
    
    /**
     * Crear preferencia de pago
     */
    public function createPreference($reserva_data) {
        $preference = [
            'items' => [
                [
                    'id' => 'reserva_' . $reserva_data['reserva_id'],
                    'title' => "Reserva de parqueo - {$reserva_data['parqueadero_nombre']}",
                    'description' => "Espacio {$reserva_data['numero_espacio']} - {$reserva_data['placa_vehiculo']}",
                    'quantity' => 1,
                    'unit_price' => (float)$reserva_data['total_amount'],
                    'currency_id' => $this->config['mercadopago']['currency']
                ]
            ],
            'payer' => [
                'name' => $reserva_data['usuario_nombre'],
                'email' => $reserva_data['usuario_email']
            ],
            'back_urls' => [
                'success' => $this->config['mercadopago']['success_url'],
                'failure' => $this->config['mercadopago']['failure_url'],
                'pending' => $this->config['mercadopago']['pending_url']
            ],
            'auto_return' => 'all', // Cambiado a 'all' para manejar todos los estados
            'external_reference' => $reserva_data['reference_code'],
            'notification_url' => $this->config['mercadopago']['webhook_url'],
            'statement_descriptor' => 'EASYPARK',
            'metadata' => [
                'reserva_id' => $reserva_data['reserva_id'],
                'parqueadero' => $reserva_data['parqueadero_nombre'],
                'placa' => $reserva_data['placa_vehiculo']
            ]
        ];
        
        // Verificar que cURL esté disponible
        if (!function_exists('curl_version')) {
            return ['error' => 'cURL no está disponible en el servidor'];
        }

        $response = $this->sendRequest('/checkout/preferences', $preference);

        // Normalizar la respuesta para que siempre devolvamos un array con 'id' o 'error'
        if (is_array($response) && isset($response['id'])) {
            return ['id' => $response['id'], 'raw' => $response];
        }

        // Si la API devolvió un error o estructura inesperada, intentar extraer mensaje
        $errorMsg = 'Respuesta inesperada de Mercado Pago';
        if (is_array($response)) {
            if (isset($response['message'])) $errorMsg = $response['message'];
            elseif (isset($response['error'])) $errorMsg = json_encode($response['error']);
            elseif (isset($response['cause'])) $errorMsg = json_encode($response['cause']);
        }

        return ['error' => $errorMsg, 'raw' => $response];
    }
    
    /**
     * Obtener información de un pago
     */
    public function getPayment($payment_id) {
        return $this->sendRequest("/v1/payments/$payment_id", null, 'GET');
    }
    
    /**
     * Enviar solicitud a Mercado Pago
     */
    private function sendRequest($endpoint, $data = null, $method = 'POST') {
        $url = $this->credentials['base_url'] . $endpoint;
        
        $headers = [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $this->credentials['access_token']
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        if ($method === 'POST' && $data) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return ['error' => 'Error de conexión: ' . $error];
        }
        
        $data = json_decode($response, true);
        
        if ($http_code >= 400) {
            return ['error' => 'Error HTTP: ' . $http_code, 'response' => $data];
        }
        
        return $data;
    }
    
    /**
     * Obtener URL de pago
     */
    public function getPaymentUrl($preference_id) {
        $base_url = $this->config['mercadopago']['environment'] === 'sandbox' 
            ? 'https://sandbox.mercadopago.com.co/checkout/v1/redirect?pref_id='
            : 'https://www.mercadopago.com.co/checkout/v1/redirect?pref_id=';
            
        return $base_url . $preference_id;
    }
    
    /**
     * Verificar webhook de Mercado Pago
     */
    public function verifyWebhook($data) {
        // Mercado Pago envía el ID del pago en el webhook
        if (isset($data['data']['id'])) {
            $payment_id = $data['data']['id'];
            return $this->getPayment($payment_id);
        }
        
        return false;
    }
    
    /**
     * Obtener public key para el frontend
     */
    public function getPublicKey() {
        return $this->credentials['public_key'];
    }
    
    /**
     * Obtener información del ambiente
     */
    public function getEnvironment() {
        return $this->config['mercadopago']['environment'];
    }
}
