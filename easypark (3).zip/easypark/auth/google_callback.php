<?php
// auth/google_callback.php - Callback de Google OAuth
session_start();
include '../conexion.php';
include '../config/google_oauth.php';

$config = include '../config/google_oauth.php';

// Verificar que tenemos el código de autorización
if (!isset($_GET['code']) || !isset($_GET['state'])) {
    header('Location: ../index.php?error=google_auth_failed');
    exit();
}

// Verificar el estado para prevenir CSRF
if ($_GET['state'] !== $_SESSION['google_oauth_state']) {
    header('Location: ../index.php?error=invalid_state');
    exit();
}

// Limpiar el estado de la sesión
unset($_SESSION['google_oauth_state']);

try {
    // Intercambiar código por token de acceso
    $token_data = [
        'client_id' => $config['google']['client_id'],
        'client_secret' => $config['google']['client_secret'],
        'code' => $_GET['code'],
        'grant_type' => 'authorization_code',
        'redirect_uri' => $config['google']['redirect_uri']
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $config['google']['token_url']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($token_data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200) {
        throw new Exception('Error al obtener token de acceso');
    }

    $token_response = json_decode($response, true);
    $access_token = $token_response['access_token'];

    // Obtener información del usuario
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $config['google']['user_info_url'] . '?access_token=' . $access_token);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $user_response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code !== 200) {
        throw new Exception('Error al obtener información del usuario');
    }

    $user_data = json_decode($user_response, true);

    // Verificar si el usuario ya existe en nuestra base de datos
    $email = $user_data['email'];
    $google_id = $user_data['id'];

    // Buscar usuario existente por email
    $sql_usuario = "SELECT id, nombre, email FROM usuarios WHERE email = '$email'";
    $result_usuario = $conn->query($sql_usuario);

    if ($result_usuario->num_rows > 0) {
        // Usuario existe, iniciar sesión
        $usuario = $result_usuario->fetch_assoc();
        $usuario_id = $usuario['id'];

        // Verificar si ya tiene registro de Google
        $sql_google = "SELECT id FROM usuarios_google WHERE google_id = '$google_id'";
        $result_google = $conn->query($sql_google);

        if ($result_google->num_rows == 0) {
            // Vincular cuenta de Google
            $sql_link = "INSERT INTO usuarios_google (google_id, usuario_id, email, nombre, foto_url) 
                        VALUES ('$google_id', '$usuario_id', '$email', '{$user_data['name']}', '{$user_data['picture']}')";
            $conn->query($sql_link);
        }
    } else {
        // Crear nuevo usuario
        $nombre = $conn->real_escape_string($user_data['name']);
        $email_escaped = $conn->real_escape_string($email);
        
        // Crear usuario con rol cliente por defecto
        $sql_nuevo_usuario = "INSERT INTO usuarios (nombre, email, contrasena, rol) 
                             VALUES ('$nombre', '$email_escaped', '', 'cliente')";
        
        if ($conn->query($sql_nuevo_usuario)) {
            $usuario_id = $conn->insert_id;
            
            // Crear registro de Google
            $sql_google_nuevo = "INSERT INTO usuarios_google (google_id, usuario_id, email, nombre, foto_url) 
                                VALUES ('$google_id', '$usuario_id', '$email_escaped', '$nombre', '{$user_data['picture']}')";
            $conn->query($sql_google_nuevo);
        } else {
            throw new Exception('Error al crear usuario: ' . $conn->error);
        }
    }

    // Iniciar sesión
    $_SESSION['usuario_id'] = $usuario_id;
    $_SESSION['nombre'] = $user_data['name'];
    $_SESSION['email'] = $email;
    $_SESSION['rol'] = 'cliente'; // Por defecto cliente
    $_SESSION['login_method'] = 'google';
    $_SESSION['foto_perfil'] = $user_data['picture'];

    // Redirigir según el rol
    if ($_SESSION['rol'] === 'admin') {
        header('Location: ../Admin/Dashboard.php');
    } else {
        header('Location: ../Cliente/reservar.php');
    }
    exit();

} catch (Exception $e) {
    error_log('Error en Google OAuth: ' . $e->getMessage());
    header('Location: ../index.php?error=google_login_failed');
    exit();
}

$conn->close();
