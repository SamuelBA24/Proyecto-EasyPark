<?php
// auth/google_login.php - Iniciar login con Google
session_start();
include '../conexion.php';
include '../config/google_oauth.php';

$config = include '../config/google_oauth.php';

// Generar estado aleatorio para prevenir CSRF
$state = bin2hex(random_bytes(16));
$_SESSION['google_oauth_state'] = $state;

// Construir URL de autorización de Google
$auth_url = $config['google']['auth_url'] . '?' . http_build_query([
    'client_id' => $config['google']['client_id'],
    'redirect_uri' => $config['google']['redirect_uri'],
    'scope' => $config['google']['scope'],
    'response_type' => 'code',
    'state' => $state,
    'access_type' => 'offline',
    'prompt' => 'consent'
]);

// Redirigir a Google
header('Location: ' . $auth_url);
exit();
