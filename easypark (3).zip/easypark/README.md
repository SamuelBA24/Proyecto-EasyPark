EasyPark — Aplicación de reservas de parqueo

Este repositorio contiene el código del proyecto EasyPark (PHP). Se han removido los artefactos de pruebas unitarias por solicitud del desarrollador; un compañero deberá añadir la suite de pruebas desde cero en un branch independiente.

Qué incluye este repositorio

- Código PHP (vistas, includes, pagos)
- Configuración local (config/\*) — revisa `config/mercadopago_config.php` y reemplaza credenciales antes de ejecutar pagos
- Scripts y SQL de soporte en la raíz

Antes de subir a GitHub (recomendado)

1. Remueve credenciales sensibles del repositorio y usa variables de entorno en producción.
   - Revisa `config/mercadopago_config.php` y reemplaza tokens por variables de entorno.
2. Asegúrate de que `logs/` y `uploads/` estén en `.gitignore` (ya añadido).

Pasos para crear el repositorio en GitHub y subir el código (PowerShell)

Opción A — Usando gh (GitHub CLI) — recomendado si lo tienes instalado:

```powershell
cd C:\xampp\htdocs\easypark
# 1) Inicializar git (si aún no está)
git init
git add .
git commit -m "Initial import of EasyPark (cleaned for tests)"
# 2) Crear repo en GitHub (privado por defecto)
gh repo create tu-usuario/easypark --private --source=. --remote=origin --push
# 3) Invitar colaborador (reemplaza usuario)
gh api --method PUT /repos/tu-usuario/easypark/collaborators/colaborador-username -f permission=push
```

Opción B — Manual (Web + git)

```powershell
cd C:\xampp\htdocs\easypark
git init
git add .
git commit -m "Initial import of EasyPark (cleaned for tests)"
# En GitHub: New repository -> tu-usuario/easypark (no README)
# Luego en PowerShell (reemplaza la URL por la de tu repo)
git remote add origin https://github.com/tu-usuario/easypark.git
git branch -M main
git push -u origin main
```

Invitar colaborador vía web:

- Entra en Settings -> Manage access -> Invite a collaborator -> escribe su usuario -> Invita.

Añadir CI para pruebas (opcional)

- He incluido un workflow de ejemplo en `.github/workflows/ci.yml` que ejecuta `composer install` y `vendor/bin/phpunit` si existen; tu compañero puede ajustarlo.

Notas importantes

- NO subas credenciales (tokens, claves) ni datos reales de usuarios.
- Para pruebas de integración que requieran webhooks (MercadoPago), usa ngrok o un entorno público temporal.

Si quieres, puedo:

- Crear el repo en GitHub por ti (necesitaría tu token o que lo autorices — no puedo hacerlo sin credenciales).
- O guiarte paso a paso mientras lo creas y hacer un push desde tu máquina.

Dime qué opción prefieres: te doy los comandos exactos (reemplazando tu usuario) o te preparo el repo si puedes compartir un token seguro (recomiendo que lo hagas tú por seguridad).
