<?php
// Configuración de la Base de Datos EasyPark
$servidor = "localhost";
$usuario = "root";       // Usuario por defecto de XAMPP
$contrasena = "";        // Contraseña por defecto de XAMPP (vacía)
$base_de_datos = "easypark"; // El nombre de la BD que creaste

// Conexión usando MySQLi orientado a objetos
$conn = new mysqli($servidor, $usuario, $contrasena, $base_de_datos);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión a la base de datos: " . $conn->connect_error);
}

// Opcional: Establecer el juego de caracteres a UTF8
$conn->set_charset("utf8");

// Este archivo solo establece la conexión. No genera salida HTML.
?>