<?php
// Configuración para Google OAuth
// Obtener estas credenciales desde: https://console.developers.google.com/

return [
    'google' => [
        'client_id' => '675898813463-i1feuj0uds7n8oj8andehsilcge59avt.apps.googleusercontent.com',
        'client_secret' => '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',
        'redirect_uri' => 'http://localhost/easypark/auth/google_callback.php',
        'scope' => 'email profile',
        'auth_url' => 'https://accounts.google.com/o/oauth2/auth',
        'token_url' => 'https://oauth2.googleapis.com/token',
        'user_info_url' => 'https://www.googleapis.com/oauth2/v2/userinfo'
    ],
    
    'app' => [
        'ciudad_principal' => 'Medellín',
        'coordenadas_ciudad' => [
            'lat' => 6.2442,
            'lng' => -75.5812
        ],
        'zoom_default' => 12,
        'radio_busqueda_km' => 10
    ]
];
