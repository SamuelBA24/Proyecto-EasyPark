<?php
// Configuración para Mercado Pago Colombia
// Obtener estas credenciales desde: https://www.mercadopago.com.co/developers/

return [
    'mercadopago' => [
        // Credenciales de prueba (Sandbox)
        'sandbox' => [
            'access_token' => 'TEST-652895993312436-110213-5ebe63dbfdd4dbabb386a99807a54059-2953029275',
            'public_key' => 'TEST-5e1105b6-df35-4923-8cfd-11951ee2f12b',
            'base_url' => 'https://api.mercadopago.com'
        ],
        
        // Credenciales de producción
        'production' => [
            'access_token' => 'TU_ACCESS_TOKEN_PRODUCCION_AQUI',
            'public_key' => 'TU_PUBLIC_KEY_PRODUCCION_AQUI',
            'base_url' => 'https://api.mercadopago.com'
        ],
        
        // Configuración general
        'environment' => 'sandbox', // Cambiar a 'production' en producción
        'currency' => 'COP',
        'country' => 'CO',
        'language' => 'es-CO',
        
        // URLs de respuesta
        'success_url' => 'https://charise-dualistic-brigida.ngrok-free.dev/easypark/pagos/mp_success.php',
        'failure_url' => 'https://charise-dualistic-brigida.ngrok-free.dev/easypark/pagos/mp_failure.php',
        'pending_url' => 'https://charise-dualistic-brigida.ngrok-free.dev/easypark/pagos/mp_pending.php',
        'webhook_url' => 'https://charise-dualistic-brigida.ngrok-free.dev/easypark/pagos/mp_webhook.php'
    ],
    
    'app' => [
        'name' => 'EasyPark',
        'description' => 'Sistema de reservas de parqueo',
        'logo_url' => 'https://charise-dualistic-brigida.ngrok-free.dev/easypark/img/logo2.png',
        'back_url' => 'https://charise-dualistic-brigida.ngrok-free.dev/easypark/Cliente/reservar.php'
    ]
];
