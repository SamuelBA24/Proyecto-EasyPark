<?php
// Configuración para PayU Colombia
// Obtener estas credenciales desde: https://developers.payulatam.com/

return [
    'payu' => [
        // Credenciales de prueba (Sandbox)
        'sandbox' => [
            'merchant_id' => 'TU_MERCHANT_ID_AQUI',
            'api_key' => 'TU_API_KEY_AQUI',
            'api_login' => 'TU_API_LOGIN_AQUI',
            'base_url' => 'https://sandbox.api.payulatam.com/payments-api/4.0/service.cgi'
        ],
        
        // Credenciales de producción
        'production' => [
            'merchant_id' => 'TU_MERCHANT_ID_PRODUCCION',
            'api_key' => 'TU_API_KEY_PRODUCCION',
            'api_login' => 'TU_API_LOGIN_PRODUCCION',
            'base_url' => 'https://api.payulatam.com/payments-api/4.0/service.cgi'
        ],
        
        // Configuración general
        'environment' => 'sandbox', // Cambiar a 'production' en producción
        'currency' => 'COP',
        'country' => 'CO',
        'language' => 'es',
        
        // URLs de respuesta
        'confirmation_url' => 'http://localhost/easypark/pagos/payu_confirmation.php',
        'response_url' => 'http://localhost/easypark/pagos/payu_response.php',
        'cancel_url' => 'http://localhost/easypark/Cliente/reservar.php?error=payment_cancelled'
    ],
    
    'app' => [
        'name' => 'EasyPark',
        'description' => 'Sistema de reservas de parqueo',
        'logo_url' => 'http://localhost/easypark/img/logo2.png'
    ]
];
