<?php
// actualizar_coordenadas_parqueaderos.php
// Script para actualizar coordenadas de parqueaderos existentes en Medellín
// Ejecutar una sola vez después de actualizar la base de datos

include 'conexion.php';

// Coordenadas de ejemplo para parqueaderos en Medellín
// Estas son coordenadas reales de ubicaciones en Medellín
$coordenadas_ejemplo = [
    // Centro de Medellín
    ['lat' => 6.2442, 'lng' => -75.5812, 'direccion' => 'Centro'],
    ['lat' => 6.2500, 'lng' => -75.5700, 'direccion' => 'El Poblado'],
    ['lat' => 6.2300, 'lng' => -75.5900, 'direccion' => 'Laureles'],
    ['lat' => 6.2600, 'lng' => -75.5600, 'direccion' => 'Envigado'],
    ['lat' => 6.2200, 'lng' => -75.6000, 'direccion' => 'Belén'],
    ['lat' => 6.2700, 'lng' => -75.5500, 'direccion' => 'Sabaneta'],
    ['lat' => 6.2100, 'lng' => -75.6100, 'direccion' => 'Robledo'],
    ['lat' => 6.2800, 'lng' => -75.5400, 'direccion' => 'Itagüí']
];

// Función para obtener coordenadas usando Nominatim (OpenStreetMap)
function obtenerCoordenadas($direccion) {
    $url = "https://nominatim.openstreetmap.org/search?format=json&q=" . urlencode($direccion . ", Medellín, Colombia") . "&limit=1";
    
    $context = stream_context_create([
        'http' => [
            'header' => "User-Agent: EasyPark/1.0\r\n"
        ]
    ]);
    
    $response = file_get_contents($url, false, $context);
    $data = json_decode($response, true);
    
    if (!empty($data)) {
        return [
            'lat' => floatval($data[0]['lat']),
            'lng' => floatval($data[0]['lon'])
        ];
    }
    
    return null;
}

echo "<h2>Actualizando coordenadas de parqueaderos...</h2>";

// Obtener todos los parqueaderos que no tienen coordenadas
$sql = "SELECT id, nombre_parqueadero, direccion FROM parqueaderos WHERE coordenadas_lat IS NULL OR coordenadas_lng IS NULL";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    $contador = 0;
    $coordenadas_index = 0;
    
    while ($fila = $resultado->fetch_assoc()) {
        $parqueadero_id = $fila['id'];
        $direccion = $fila['direccion'];
        
        // Intentar obtener coordenadas reales
        $coordenadas = obtenerCoordenadas($direccion);
        
        // Si no se pueden obtener coordenadas reales, usar coordenadas de ejemplo
        if (!$coordenadas && isset($coordenadas_ejemplo[$coordenadas_index])) {
            $coordenadas = $coordenadas_ejemplo[$coordenadas_index];
            $coordenadas_index++;
        }
        
        if ($coordenadas) {
            $lat = $coordenadas['lat'];
            $lng = $coordenadas['lng'];
            
            // Actualizar en la base de datos
            $sql_update = "UPDATE parqueaderos SET coordenadas_lat = '$lat', coordenadas_lng = '$lng' WHERE id = '$parqueadero_id'";
            
            if ($conn->query($sql_update)) {
                echo "<p>✅ {$fila['nombre_parqueadero']} - Coordenadas actualizadas: {$lat}, {$lng}</p>";
                $contador++;
            } else {
                echo "<p>❌ Error actualizando {$fila['nombre_parqueadero']}: " . $conn->error . "</p>";
            }
        } else {
            echo "<p>⚠️ No se pudieron obtener coordenadas para {$fila['nombre_parqueadero']}</p>";
        }
        
        // Pequeña pausa para no sobrecargar la API
        sleep(1);
    }
    
    echo "<h3>Resumen: {$contador} parqueaderos actualizados</h3>";
} else {
    echo "<p>No hay parqueaderos sin coordenadas.</p>";
}

// Actualizar categorías de tarifa basadas en el precio
echo "<h2>Actualizando categorías de tarifa...</h2>";

$sql_categorias = "UPDATE parqueaderos SET categoria_tarifa = CASE 
    WHEN tarifa_hora < 3000 THEN 'economica'
    WHEN tarifa_hora <= 8000 THEN 'media'
    ELSE 'premium'
END";

if ($conn->query($sql_categorias)) {
    echo "<p>✅ Categorías de tarifa actualizadas correctamente</p>";
} else {
    echo "<p>❌ Error actualizando categorías: " . $conn->error . "</p>";
}

// Actualizar tipos de vehículo permitidos (por defecto todos)
$sql_tipos = "UPDATE parqueaderos SET tipos_vehiculo_permitidos = 'carro,moto,bicicleta' WHERE tipos_vehiculo_permitidos IS NULL OR tipos_vehiculo_permitidos = ''";

if ($conn->query($sql_tipos)) {
    echo "<p>✅ Tipos de vehículo permitidos actualizados</p>";
} else {
    echo "<p>❌ Error actualizando tipos de vehículo: " . $conn->error . "</p>";
}

$conn->close();

echo "<h3>¡Actualización completada!</h3>";
echo "<p><a href='Cliente/reservar.php'>Ir a reservar</a></p>";
?>
