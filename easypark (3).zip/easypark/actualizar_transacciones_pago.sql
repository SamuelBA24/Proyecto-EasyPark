-- Crear tabla de transacciones_pago si no existe
CREATE TABLE IF NOT EXISTS transacciones_pago (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reserva_id INT NOT NULL,
    metodo_pago VARCHAR(50) NOT NULL,
    referencia_pago VARCHAR(100) NOT NULL,
    preference_id VARCHAR(100),
    payment_id VARCHAR(100),
    monto DECIMAL(10,2) NOT NULL,
    estado VARCHAR(20) NOT NULL,
    respuesta_payu TEXT,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (reserva_id) REFERENCES reservas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Verificar si ya existen registros huérfanos y limpiarlos
DELETE FROM transacciones_pago 
WHERE reserva_id NOT IN (SELECT id FROM reservas);

-- Agregar índices para mejor rendimiento
CREATE INDEX IF NOT EXISTS idx_transacciones_reserva ON transacciones_pago(reserva_id);
CREATE INDEX IF NOT EXISTS idx_transacciones_referencia ON transacciones_pago(referencia_pago);
CREATE INDEX IF NOT EXISTS idx_transacciones_preference ON transacciones_pago(preference_id);
CREATE INDEX IF NOT EXISTS idx_transacciones_payment ON transacciones_pago(payment_id);