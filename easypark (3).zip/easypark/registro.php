<?php
session_start();
include 'conexion.php'; 

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. Obtener y sanear los datos
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $email = $conn->real_escape_string($_POST['email']);
    $contrasena = $_POST['contrasena'];
    
    // Obtener el rol seleccionado (cliente o admin)
    $rol = $conn->real_escape_string($_POST['rol_registro']); 

    // **NOTA DE SEGURIDAD:** En producción, esto debería ser password_hash()
    $contrasena_plana = $contrasena;

    // 2. Ejecutar la inserción en la base de datos
    $sql = "INSERT INTO usuarios (nombre, email, contrasena, rol) 
            VALUES ('$nombre', '$email', '$contrasena_plana', '$rol')";

    if ($conn->query($sql) === TRUE) {
        // Redirigir al usuario al login para que inicie su sesión
        header("Location: index.php?msg=" . urlencode("Registro exitoso como " . ucfirst($rol) . ". ¡Inicia sesión!"));
        $conn->close();
        exit();
    } else {
        // 3. Manejo de error
        if ($conn->errno == 1062) {
            $mensaje = "Error: El email ya está registrado.";
        } else {
            $mensaje = "Error al registrar: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>EasyPark - Registro</title>
    <style>
        :root {
            --bg: #f8fafc;
            --card: #fff;
            --accent: #24b358;
            --accent-2: #1e8f40;
            --muted: #6b7280;
            --radius: 18px;
            --shadow: 0 8px 32px rgba(16,32,64,0.07);
        }
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
        html,body{height:100%}
        body {
            font-family: 'Inter', Arial, sans-serif;
            background: var(--bg);
            color: #1a2330;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
    /* logo for registro page */
    .page-logo{display:flex;flex-direction:column;align-items:center;gap:12px;margin-bottom:24px}
    .page-logo img{height:80px;width:auto}
    .page-logo .brand{font-weight:700;color:var(--accent);font-size:1.05em;text-align:center}
        .registro-container {
            background: var(--card);
            padding: 38px 32px 28px 32px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 340px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h2 {
            text-align: center;
            color: var(--accent);
            font-size: 1.5em;
            font-weight: 700;
            margin-bottom: 18px;
            letter-spacing: 0.5px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 500;
            color: #1a2330;
            text-align: left;
        }
        input[type="text"], input[type="email"], input[type="password"], select {
            width: 100%;
            padding: 12px 14px;
            margin-bottom: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-sizing: border-box;
            font-size: 1em;
            background: #f8fafc;
            color: #1a2330;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus, select:focus {
            border-color: var(--accent);
            outline: none;
        }
        button {
            width: 100%;
            padding: 12px 0;
            background: linear-gradient(90deg,var(--accent),var(--accent-2));
            color: #f4f4f4;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1em;
            letter-spacing: 0.5px;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(16,32,64,0.07);
            margin-top: 4px;
            margin-bottom: 5px;
            transition: background 0.2s, transform 0.15s;
        }
        button:hover {
            background: linear-gradient(90deg,#1e8f40,#24b358);
            transform: translateY(-2px) scale(1.02);
        }
        .mensaje-error {
            color: #e53e3e;
            background: #fff0f0;
            border-radius: 8px;
            padding: 8px 0;
            text-align: center;
            margin-bottom: 15px;
            font-size: 0.98em;
        }
        .links-container {
            text-align: center;
            margin-top: 18px;
            font-size: 0.98em;
        }
        .links-container a {
            color: var(--accent);
            text-decoration: none;
            margin: 0 5px;
            padding: 2px 6px;
            border-radius: 6px;
            transition: background 0.18s;
        }
        .links-container a:hover {
            background: #f0f8ff;
            text-decoration: underline;
        }
        @media (max-width:900px){
            .registro-container{max-width:98vw;padding:18px 2vw;}
        }
        @media (max-width:480px){
            .registro-container{padding:12px 2vw;max-width:99vw;}
            h2{font-size:1em;}
            label{font-size:0.98em;}
            button{font-size:0.98em;}
        }
    </style>
</head>

<body>
    <div class="registro-container">
        <div class="page-logo">
            <img src="img/logo2.png" alt="EasyPark Logo" />
            <div class="brand">Registro de Usuario</div>
        </div>
        
        <?php if ($mensaje): ?>
            <p class="mensaje-error"><?php echo $mensaje; ?></p>
        <?php endif; ?>
        
        <form action="registro.php" method="POST">
            <label for="nombre">Nombre Completo:</label>
            <input type="text" id="nombre" name="nombre" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" required>
            
            <label for="rol_registro">Tipo de Cuenta:</label>
            <select id="rol_registro" name="rol_registro" required>
                <option value="cliente">Cliente (Quiero reservar)</option>
                <option value="admin">Administrador (Soy dueño de parqueadero)</option>
            </select>

            <button type="submit">Registrarse</button>
        </form>
        
        <div class="links-container">
            <p>
                ¿Ya tienes cuenta? <a href="index.php">Iniciar Sesión</a>
                | 
                <a href="bienvenida.html">Página Principal</a> </p>
        </div>
    </div>
</body>

</html>