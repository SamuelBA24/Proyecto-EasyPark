# Configuración de Google OAuth para EasyPark

## Pasos para configurar el login con Google:

### 1. Crear un proyecto en Google Cloud Console

1. Ve a [Google Cloud Console](https://console.cloud.google.com/)
2. Crea un nuevo proyecto o selecciona uno existente
3. Habilita la API de Google+ (ahora Google Identity)

### 2. Configurar OAuth 2.0

1. Ve a "APIs y servicios" > "Credenciales"
2. Haz clic en "Crear credenciales" > "ID de cliente OAuth 2.0"
3. Selecciona "Aplicación web"
4. Configura los URIs de redirección autorizados:
   - `http://localhost/easypark/auth/google_callback.php` (para desarrollo)
   - `https://tudominio.com/easypark/auth/google_callback.php` (para producción)

### 3. Actualizar la configuración

1. Copia el "ID de cliente" y "Secreto del cliente"
2. Edita el archivo `config/google_oauth.php`
3. Reemplaza los valores:
   ```php
   'client_id' => 'TU_GOOGLE_CLIENT_ID_AQUI',
   'client_secret' => 'TU_GOOGLE_CLIENT_SECRET_AQUI',
   ```

### 4. Actualizar la base de datos

Ejecuta el script SQL `actualizar_base_datos.sql` en phpMyAdmin para agregar los nuevos campos.

### 5. Configurar coordenadas de parqueaderos

Los parqueaderos existentes necesitan coordenadas. Puedes:

- Usar Google Maps para obtener coordenadas
- Actualizar manualmente en la base de datos
- Usar la API de geocodificación

## Características implementadas:

✅ **Sistema de filtros avanzado:**

- Filtro por tipo de vehículo (carro, moto, bicicleta)
- Filtro por categoría de tarifa (económica, media, premium)
- Filtro por distancia máxima

✅ **Geolocalización específica para Medellín:**

- Mapa centrado en Medellín
- Marcadores personalizados con logo de la app
- Iconos distintivos para parqueaderos y usuario

✅ **Login social con Google:**

- Autenticación OAuth 2.0
- Vinculación automática de cuentas
- Creación automática de usuarios nuevos

✅ **Interfaz mejorada:**

- Diseño moderno y responsive
- Información detallada de parqueaderos
- Categorización visual de tarifas

## Archivos modificados/creados:

- `Cliente/reservar.php` - Sistema de filtros y mapa mejorado
- `index.php` - Botón de login con Google
- `auth/google_login.php` - Iniciador de OAuth
- `auth/google_callback.php` - Callback de OAuth
- `config/google_oauth.php` - Configuración de Google
- `actualizar_base_datos.sql` - Script de actualización de BD

## Próximos pasos recomendados:

1. Configurar las credenciales de Google OAuth
2. Ejecutar el script SQL de actualización
3. Probar el sistema de filtros
4. Configurar coordenadas reales de parqueaderos
5. Probar el login con Google
