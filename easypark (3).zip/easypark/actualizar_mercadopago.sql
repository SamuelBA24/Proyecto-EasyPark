-- Script para actualizar métodos de pago a Mercado Pago
-- Ejecutar en phpMyAdmin

-- 1. Actualizar métodos de pago existentes
UPDATE metodos_pago SET 
    codigo = 'mercadopago',
    nombre = 'Mercado Pago',
    descripcion = 'Pago seguro con tarjeta de crédito o débito',
    logo_url = 'https://http2.mlstatic.com/storage/logos-api-admin/a5f047d0-9be0-11ec-aad4-c3381f368aaf-m.svg',
    activo = TRUE,
    orden = 2
WHERE codigo = 'payu';

-- 2. Si no existe el método de Mercado Pago, crearlo
INSERT IGNORE INTO metodos_pago (codigo, nombre, descripcion, logo_url, activo, orden) VALUES 
('mercadopago', 'Mercado Pago', 'Pago seguro con tarjeta de crédito o débito', 'https://http2.mlstatic.com/storage/logos-api-admin/a5f047d0-9be0-11ec-aad4-c3381f368aaf-m.svg', TRUE, 2);

-- 3. Actualizar tabla de transacciones para Mercado Pago
ALTER TABLE transacciones_pago 
MODIFY COLUMN metodo_pago VARCHAR(50) NOT NULL COMMENT 'Método de pago utilizado';

-- 4. Actualizar reservas existentes que usaban PayU
UPDATE reservas SET 
    metodo_pago = 'mercadopago',
    referencia_pago = CONCAT('MP', UNIX_TIMESTAMP(), id),
    transaction_id = NULL
WHERE metodo_pago = 'payu';

-- 5. Actualizar transacciones existentes
UPDATE transacciones_pago SET 
    metodo_pago = 'mercadopago'
WHERE metodo_pago = 'payu';

-- 6. Agregar campos específicos para Mercado Pago
ALTER TABLE transacciones_pago 
ADD COLUMN preference_id VARCHAR(100) NULL COMMENT 'ID de preferencia de Mercado Pago',
ADD COLUMN payment_id VARCHAR(100) NULL COMMENT 'ID de pago de Mercado Pago';

-- 7. Crear índices para Mercado Pago
CREATE INDEX idx_transacciones_preference_id ON transacciones_pago(preference_id);
CREATE INDEX idx_transacciones_payment_id ON transacciones_pago(payment_id);

-- 8. Comentarios sobre el uso
-- Mercado Pago usa preferencias en lugar de transacciones directas
-- El flujo es: Crear preferencia -> Redirigir -> Webhook confirma pago
-- Los campos preference_id y payment_id almacenan los IDs de MP
-- El campo transaction_id se mantiene para compatibilidad pero se usa payment_id
