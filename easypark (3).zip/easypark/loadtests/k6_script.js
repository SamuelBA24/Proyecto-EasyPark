import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  stages: [
    { duration: '30s', target: 20 },
    { duration: '1m', target: 50 },
    { duration: '30s', target: 0 }
  ],
};

const BASE = __ENV.TEST_BASE_URL || 'http://localhost:80/easypark';

export default function () {
  const res = http.get(`${BASE}/Cliente/reservar.php`);
  check(res, { 'status is 200': (r) => r.status === 200 });
  // Simular vista y pequeña espera
  sleep(Math.random() * 2 + 1);
}
